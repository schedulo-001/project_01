import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { generateCSNotes } from "./services/openai";

export async function registerRoutes(app: Express): Promise<Server> {
  // Chat endpoint for AI assistant
  app.post("/api/chat", async (req, res) => {
    try {
      const { message } = req.body;
      
      if (!message || typeof message !== 'string') {
        return res.status(400).json({ error: "Message is required" });
      }

      // Generate response using OpenAI
      const response = await generateCSNotes(message);
      
      res.json({
        response: response.content,
        topic: response.topic
      });
    } catch (error) {
      console.error("Chat API error:", error);
      res.status(500).json({ 
        error: "Failed to generate response",
        message: "The AI assistant is temporarily unavailable. Please try again later."
      });
    }
  });

  // Get available algorithms endpoint
  app.get("/api/algorithms", (req, res) => {
    const algorithms = [
      {
        id: 'fcfs',
        name: 'First Come First Serve',
        description: 'Non-preemptive scheduling based on arrival time',
        category: 'scheduling'
      },
      {
        id: 'sjf',
        name: 'Shortest Job First',
        description: 'Non-preemptive scheduling based on burst time',
        category: 'scheduling'
      },
      {
        id: 'srtf',
        name: 'Shortest Remaining Time First',
        description: 'Preemptive version of SJF',
        category: 'scheduling'
      },
      {
        id: 'ljf',
        name: 'Longest Job First',
        description: 'Non-preemptive scheduling, longest job first',
        category: 'scheduling'
      },
      {
        id: 'lrtf',
        name: 'Longest Remaining Time First',
        description: 'Preemptive version of LJF',
        category: 'scheduling'
      },
      {
        id: 'hrrn',
        name: 'Highest Response Ratio Next',
        description: 'Based on response ratio calculation',
        category: 'scheduling'
      },
      {
        id: 'rr',
        name: 'Round Robin',
        description: 'Time quantum based preemptive scheduling',
        category: 'scheduling'
      },
      {
        id: 'priority',
        name: 'Priority Scheduling',
        description: 'Based on process priority values',
        category: 'scheduling'
      },
      {
        id: 'mlq',
        name: 'Multilevel Queue',
        description: 'Multiple queues with different priorities',
        category: 'scheduling'
      },
      {
        id: 'mlfq',
        name: 'Multilevel Feedback Queue',
        description: 'Dynamic priority adjustment between queues',
        category: 'scheduling'
      }
    ];
    
    res.json(algorithms);
  });

  // Process simulation endpoint
  app.post("/api/simulate", async (req, res) => {
    try {
      const { algorithm, processes, options } = req.body;
      
      if (!algorithm || !processes) {
        return res.status(400).json({ error: "Algorithm and processes are required" });
      }

      // Here you would run the actual simulation
      // For now, return mock data
      const simulation = {
        algorithm,
        ganttChart: [
          { processId: 'P1', start: 0, end: 5 },
          { processId: 'P2', start: 5, end: 8 },
          { processId: 'P3', start: 8, end: 16 }
        ],
        statistics: {
          averageWaitingTime: 4.33,
          averageTurnaroundTime: 9.67,
          cpuUtilization: 100
        }
      };
      
      res.json(simulation);
    } catch (error) {
      console.error("Simulation error:", error);
      res.status(500).json({ error: "Simulation failed" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
