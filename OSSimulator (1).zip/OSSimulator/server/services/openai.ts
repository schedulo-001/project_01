import OpenAI from "openai";

// the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
const openai = new OpenAI({ 
  apiKey: process.env.OPENAI_API_KEY || "your-api-key-here" 
});

interface CSNotesResponse {
  content: string;
  topic: string;
}

export async function generateCSNotes(query: string): Promise<CSNotesResponse> {
  try {
    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: `You are an expert Computer Science tutor specializing in Operating Systems, Data Structures, Algorithms, and related CS concepts. Your role is to:

1. Provide detailed, accurate explanations of CS concepts
2. Use examples and analogies to make complex topics understandable
3. Structure your responses with clear headings and bullet points
4. Include practical examples and code snippets when relevant
5. Explain the "why" behind concepts, not just the "what"
6. Relate concepts to real-world applications
7. For Operating Systems topics, focus on:
   - Process management and scheduling algorithms
   - Memory management techniques
   - File systems and I/O
   - Synchronization and deadlocks
   - Virtual memory and paging

Format your response as detailed educational notes that a BCA final year student would find helpful for their studies and projects.

Respond with JSON in this format: { "content": "detailed explanation", "topic": "identified topic category" }`
        },
        {
          role: "user",
          content: query
        }
      ],
      response_format: { type: "json_object" },
      max_tokens: 2000,
      temperature: 0.7
    });

    const result = JSON.parse(response.choices[0].message.content || '{}');
    
    return {
      content: result.content || "I apologize, but I couldn't generate a proper response. Please try rephrasing your question.",
      topic: result.topic || "General CS"
    };
  } catch (error) {
    console.error("OpenAI API error:", error);
    
    // Fallback response
    return {
      content: `I understand you're asking about: "${query}"

This appears to be related to computer science concepts. Here's a general explanation:

**Key Points:**
• This is an important topic in computer science education
• It relates to fundamental concepts that are essential for understanding system operations
• Practical knowledge of this topic is valuable for software development

**For BCA Students:**
• Understanding these concepts is crucial for your final year project
• These topics often appear in technical interviews
• Practical implementation helps solidify theoretical knowledge

**Recommendation:**
I'm currently experiencing some technical difficulties with my advanced AI capabilities. For the most accurate and detailed explanation of this specific topic, I recommend:
1. Consulting your textbooks for foundational understanding
2. Looking up specific examples online
3. Trying to rephrase your question more specifically

Please try asking your question again, and I'll do my best to provide a detailed response!`,
      topic: "General CS Concepts"
    };
  }
}

// Additional helper function for generating algorithm explanations
export async function generateAlgorithmExplanation(algorithmName: string): Promise<string> {
  try {
    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: "You are a CS tutor explaining scheduling algorithms. Provide a clear, detailed explanation of the algorithm including how it works, advantages, disadvantages, and time complexity."
        },
        {
          role: "user",
          content: `Explain the ${algorithmName} scheduling algorithm in detail.`
        }
      ],
      max_tokens: 1000,
      temperature: 0.3
    });

    return response.choices[0].message.content || "Unable to generate explanation.";
  } catch (error) {
    console.error("Algorithm explanation error:", error);
    return `Error generating explanation for ${algorithmName}. Please try again later.`;
  }
}
