# Operating System Learning Game

## Overview

This is an interactive 3D educational game designed to teach Computer Science concepts, specifically Operating Systems topics like process scheduling, memory management, and deadlock handling. The application combines a React Three Fiber 3D environment with an AI-powered chatbot assistant to create an engaging learning experience for BCA final year students.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **3D Engine**: React Three Fiber (R3F) with Three.js for 3D visualizations
- **UI Components**: Radix UI primitives with custom shadcn/ui components
- **Styling**: Tailwind CSS with CSS custom properties for theming
- **State Management**: Zustand stores for game state, audio, and scheduling simulations
- **Build Tool**: Vite with custom configuration for 3D assets

### Backend Architecture
- **Runtime**: Node.js with Express.js server
- **Language**: TypeScript with ES modules
- **Database**: PostgreSQL with Drizzle ORM (configured but using in-memory storage currently)
- **AI Integration**: OpenAI GPT-4o for educational content generation
- **Development**: Full-stack development with Vite middleware in dev mode

### Key Design Decisions

**3D Visualization Choice**: React Three Fiber was selected over plain Three.js to leverage React's component model for organizing complex 3D scenes. This allows for better state management and component reusability in educational visualizations.

**AI-Powered Learning Assistant**: Integrated OpenAI GPT-4o to provide personalized explanations of CS concepts. The AI is specifically prompted to act as a CS tutor, ensuring educational relevance and proper academic tone.

**In-Memory vs Database Storage**: Currently using in-memory storage for user data instead of the configured PostgreSQL database. This decision prioritizes development speed and simplicity for the educational prototype.

## Key Components

### 3D Visualization System
- **Scene Management**: Centralized scene component that renders different visualizations based on current topic
- **Process Visualization**: 3D nodes representing process states with color-coded animations
- **Memory Management**: Visual blocks representing memory allocation with dynamic sizing
- **Scheduling Algorithms**: Interactive gantt charts and CPU core representations

### Game State Management
- **useGameState**: Manages overall game phases (menu, learning, playing) and current topics
- **useScheduling**: Handles algorithm simulations with step-by-step execution
- **useAudio**: Controls background music and sound effects for enhanced engagement

### Educational Content System
- **Interactive Chatbot**: Real-time AI assistant for answering CS questions
- **Topic-Based Learning**: Structured curriculum covering process states, scheduling, and memory management
- **Visual Algorithm Demonstrations**: Step-by-step animated explanations of scheduling algorithms

## Data Flow

1. **User Input**: Keyboard controls and UI interactions captured by React event handlers
2. **State Updates**: Zustand stores update based on user actions and game logic
3. **3D Rendering**: React Three Fiber components react to state changes and update 3D scene
4. **AI Interaction**: User questions sent to Express backend, processed by OpenAI, and responses returned
5. **Visual Feedback**: Audio cues and visual animations provide immediate feedback

## External Dependencies

### Core Technologies
- **@react-three/fiber**: 3D rendering engine integration with React
- **@react-three/drei**: Utility components for common 3D patterns
- **@tanstack/react-query**: Server state management for API calls
- **drizzle-orm**: Type-safe SQL query builder and ORM
- **@neondatabase/serverless**: PostgreSQL driver for serverless environments

### UI and Styling
- **@radix-ui/***: Accessible, unstyled UI primitives
- **tailwindcss**: Utility-first CSS framework
- **class-variance-authority**: Type-safe variant API for component styling

### Development Tools
- **tsx**: TypeScript execution for Node.js
- **vite**: Fast build tool with HMR support
- **esbuild**: Fast JavaScript bundler for production builds

## Deployment Strategy

### Development Environment
- **Concurrent Development**: Vite dev server serves frontend with hot module replacement
- **Backend Integration**: Express server runs alongside with API routes
- **Asset Handling**: Support for 3D models (.gltf, .glb) and audio files

### Production Build
- **Frontend**: Vite builds optimized React bundle to `dist/public`
- **Backend**: esbuild bundles Express server to `dist/index.js`
- **Static Assets**: 3D models, textures, and audio files served from public directory

### Database Configuration
- **Development**: Uses Drizzle with PostgreSQL connection string from environment
- **Migration System**: Drizzle Kit handles schema migrations in `./migrations`
- **Schema Definition**: Type-safe database schema in `shared/schema.ts`

The application is designed to be deployed on platforms supporting Node.js with environment variables for database connection and OpenAI API key configuration.