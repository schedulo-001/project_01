export type ProcessState = 'new' | 'ready' | 'running' | 'waiting' | 'terminated';

export interface Process {
  id: string;
  name: string;
  burstTime: number;
  arrivalTime: number;
  priority: number;
  state: ProcessState;
  remainingTime?: number;
  startTime?: number;
  completionTime?: number;
  waitingTime?: number;
  turnaroundTime?: number;
}

export interface GanttSegment {
  processId: string;
  start: number;
  end: number;
  color?: string;
}

export interface MemoryBlock {
  address: string;
  size: number;
  isAllocated: boolean;
  processId?: string;
  startAddress: number;
  endAddress: number;
}

export interface SchedulingResult {
  ganttChart: GanttSegment[];
  averageWaitingTime: number;
  averageTurnaroundTime: number;
  cpuUtilization: number;
  processDetails: Process[];
}

export type SchedulingAlgorithm = 
  | 'FCFS' 
  | 'SJF' 
  | 'SRTF' 
  | 'LJF' 
  | 'LRTF' 
  | 'HRRN' 
  | 'Round Robin' 
  | 'Priority' 
  | 'Multilevel Queue' 
  | 'Multilevel Feedback Queue';

export type MemoryAllocationAlgorithm = 'first-fit' | 'best-fit' | 'worst-fit';
