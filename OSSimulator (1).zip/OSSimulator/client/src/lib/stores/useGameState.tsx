import { create } from 'zustand';
import { subscribeWithSelector } from 'zustand/middleware';

export type GamePhase = 'menu' | 'playing' | 'learning' | 'concept-selection';
export type TopicId = 'process-states' | 'scheduling' | 'memory' | 'process-management' | 'cpu-scheduling' | 'memory-management' | 'file-systems' | 'deadlock-handling' | 'synchronization';

interface GameState {
  gamePhase: GamePhase;
  currentTopic: TopicId | null;
  progress: number;
  score: number;
  completedTopics: TopicId[];
  
  // Actions
  setGamePhase: (phase: GamePhase) => void;
  setCurrentTopic: (topic: TopicId | null) => void;
  startGame: () => void;
  endGame: () => void;
  updateProgress: (progress: number) => void;
  addScore: (points: number) => void;
  completeTopic: (topic: TopicId) => void;
  resetGame: () => void;
}

export const useGameState = create<GameState>()(
  subscribeWithSelector((set, get) => ({
    gamePhase: 'menu',
    currentTopic: null,
    progress: 0,
    score: 0,
    completedTopics: [],
    
    setGamePhase: (phase) => set({ gamePhase: phase }),
    
    setCurrentTopic: (topic) => set({ currentTopic: topic }),
    
    startGame: () => set({ 
      gamePhase: 'playing',
      currentTopic: 'process-states', // Default to show process visualization first
      progress: 0,
      score: 0 
    }),
    
    endGame: () => set({ 
      gamePhase: 'menu',
      currentTopic: null 
    }),
    
    updateProgress: (progress) => set({ progress }),
    
    addScore: (points) => set((state) => ({ 
      score: state.score + points 
    })),
    
    completeTopic: (topic) => set((state) => ({
      completedTopics: [...state.completedTopics, topic],
      progress: Math.min(100, state.progress + 33.33) // 3 topics = 100%
    })),
    
    resetGame: () => set({
      gamePhase: 'menu',
      currentTopic: null,
      progress: 0,
      score: 0,
      completedTopics: []
    })
  }))
);
