import { create } from 'zustand';
import { ProcessState } from '@/lib/types';
import { 
  fcfsAlgorithm, 
  sjfAlgorithm, 
  roundRobinAlgorithm,
  priorityAlgorithm,
  srtfAlgorithm
} from '@/lib/algorithms';

interface Process {
  id: string;
  name: string;
  burstTime: number;
  arrivalTime: number;
  priority: number;
  state: ProcessState;
  remainingTime?: number;
}

interface GanttSegment {
  processId: string;
  start: number;
  end: number;
}

interface SchedulingState {
  processes: Process[];
  currentAlgorithm: string | null;
  isRunning: boolean;
  currentStep: number;
  totalSteps: number;
  ganttChart: GanttSegment[];
  currentTime: number;
  
  // Statistics
  averageWaitingTime: number;
  averageTurnaroundTime: number;
  cpuUtilization: number;
  
  // Actions
  setProcesses: (processes: Process[]) => void;
  startSimulation: (algorithm: string) => void;
  pauseSimulation: () => void;
  resetSimulation: () => void;
  stepForward: () => void;
  stepBackward: () => void;
  runAlgorithm: (algorithm: string, processes: Process[]) => GanttSegment[];
}

export const useScheduling = create<SchedulingState>((set, get) => ({
  processes: [
    { id: 'P1', name: 'Process A', burstTime: 5, arrivalTime: 0, priority: 3, state: 'ready' },
    { id: 'P2', name: 'Process B', burstTime: 3, arrivalTime: 1, priority: 1, state: 'ready' },
    { id: 'P3', name: 'Process C', burstTime: 8, arrivalTime: 2, priority: 2, state: 'ready' },
    { id: 'P4', name: 'Process D', burstTime: 6, arrivalTime: 3, priority: 4, state: 'ready' },
  ],
  currentAlgorithm: null,
  isRunning: false,
  currentStep: 0,
  totalSteps: 0,
  ganttChart: [],
  currentTime: 0,
  averageWaitingTime: 0,
  averageTurnaroundTime: 0,
  cpuUtilization: 0,
  
  setProcesses: (processes) => set({ processes }),
  
  startSimulation: (algorithm) => {
    const { processes, runAlgorithm } = get();
    const ganttChart = runAlgorithm(algorithm, processes);
    
    set({
      currentAlgorithm: algorithm,
      isRunning: true,
      currentStep: 0,
      totalSteps: ganttChart.length,
      ganttChart,
      currentTime: 0
    });
    
    // Auto-step through the simulation
    const interval = setInterval(() => {
      const state = get();
      if (state.currentStep < state.totalSteps - 1 && state.isRunning) {
        set({
          currentStep: state.currentStep + 1,
          currentTime: state.ganttChart[state.currentStep + 1]?.start || 0
        });
      } else {
        clearInterval(interval);
        set({ isRunning: false });
      }
    }, 1000);
  },
  
  pauseSimulation: () => set({ isRunning: false }),
  
  resetSimulation: () => set({
    currentStep: 0,
    currentTime: 0,
    isRunning: false,
    ganttChart: []
  }),
  
  stepForward: () => {
    const { currentStep, totalSteps, ganttChart } = get();
    if (currentStep < totalSteps - 1) {
      set({
        currentStep: currentStep + 1,
        currentTime: ganttChart[currentStep + 1]?.start || 0
      });
    }
  },
  
  stepBackward: () => {
    const { currentStep, ganttChart } = get();
    if (currentStep > 0) {
      set({
        currentStep: currentStep - 1,
        currentTime: ganttChart[currentStep - 1]?.start || 0
      });
    }
  },
  
  runAlgorithm: (algorithm, processes) => {
    switch (algorithm) {
      case 'FCFS':
        return fcfsAlgorithm(processes);
      case 'SJF':
        return sjfAlgorithm(processes);
      case 'SRTF':
        return srtfAlgorithm(processes);
      case 'Round Robin':
        return roundRobinAlgorithm(processes, 2); // quantum = 2
      case 'Priority':
        return priorityAlgorithm(processes);
      default:
        return fcfsAlgorithm(processes);
    }
  }
}));
