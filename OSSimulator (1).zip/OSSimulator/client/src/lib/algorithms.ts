import { Process, GanttSegment, SchedulingResult } from './types';

// First Come First Serve (FCFS) Algorithm
export function fcfsAlgorithm(processes: Process[]): GanttSegment[] {
  const sortedProcesses = [...processes].sort((a, b) => a.arrivalTime - b.arrivalTime);
  const ganttChart: GanttSegment[] = [];
  let currentTime = 0;
  
  sortedProcesses.forEach(process => {
    if (currentTime < process.arrivalTime) {
      currentTime = process.arrivalTime;
    }
    
    ganttChart.push({
      processId: process.id,
      start: currentTime,
      end: currentTime + process.burstTime
    });
    
    currentTime += process.burstTime;
  });
  
  return ganttChart;
}

// Shortest Job First (SJF) Algorithm
export function sjfAlgorithm(processes: Process[]): GanttSegment[] {
  const ganttChart: GanttSegment[] = [];
  const remainingProcesses = [...processes];
  let currentTime = 0;
  
  while (remainingProcesses.length > 0) {
    // Get processes that have arrived
    const availableProcesses = remainingProcesses.filter(p => p.arrivalTime <= currentTime);
    
    if (availableProcesses.length === 0) {
      // No process available, advance time to next arrival
      const nextArrival = Math.min(...remainingProcesses.map(p => p.arrivalTime));
      currentTime = nextArrival;
      continue;
    }
    
    // Select shortest job
    const shortestJob = availableProcesses.reduce((shortest, current) => 
      current.burstTime < shortest.burstTime ? current : shortest
    );
    
    ganttChart.push({
      processId: shortestJob.id,
      start: currentTime,
      end: currentTime + shortestJob.burstTime
    });
    
    currentTime += shortestJob.burstTime;
    
    // Remove completed process
    const index = remainingProcesses.findIndex(p => p.id === shortestJob.id);
    remainingProcesses.splice(index, 1);
  }
  
  return ganttChart;
}

// Shortest Remaining Time First (SRTF) Algorithm
export function srtfAlgorithm(processes: Process[]): GanttSegment[] {
  const ganttChart: GanttSegment[] = [];
  const processQueue = processes.map(p => ({ ...p, remainingTime: p.burstTime }));
  let currentTime = 0;
  let currentProcess: typeof processQueue[0] | null = null;
  
  while (processQueue.some(p => p.remainingTime > 0)) {
    // Get available processes
    const availableProcesses = processQueue.filter(
      p => p.arrivalTime <= currentTime && p.remainingTime > 0
    );
    
    if (availableProcesses.length === 0) {
      currentTime++;
      continue;
    }
    
    // Select process with shortest remaining time
    const shortestRemaining = availableProcesses.reduce((shortest, current) =>
      current.remainingTime < shortest.remainingTime ? current : shortest
    );
    
    // Check if we need to switch processes
    if (!currentProcess || currentProcess.id !== shortestRemaining.id) {
      currentProcess = shortestRemaining;
      ganttChart.push({
        processId: currentProcess.id,
        start: currentTime,
        end: currentTime + 1
      });
    } else {
      // Extend current segment
      const lastSegment = ganttChart[ganttChart.length - 1];
      if (lastSegment && lastSegment.processId === currentProcess.id) {
        lastSegment.end = currentTime + 1;
      }
    }
    
    // Execute for 1 time unit
    currentProcess.remainingTime--;
    currentTime++;
  }
  
  return ganttChart;
}

// Round Robin Algorithm
export function roundRobinAlgorithm(processes: Process[], timeQuantum: number): GanttSegment[] {
  const ganttChart: GanttSegment[] = [];
  const processQueue = processes.map(p => ({ ...p, remainingTime: p.burstTime }));
  const readyQueue: typeof processQueue = [];
  let currentTime = 0;
  let processIndex = 0;
  
  // Add first process to ready queue
  if (processes.length > 0) {
    readyQueue.push(processQueue[0]);
    processIndex = 1;
  }
  
  while (readyQueue.length > 0 || processIndex < processQueue.length) {
    // Add newly arrived processes to ready queue
    while (processIndex < processQueue.length && processQueue[processIndex].arrivalTime <= currentTime) {
      readyQueue.push(processQueue[processIndex]);
      processIndex++;
    }
    
    if (readyQueue.length === 0) {
      currentTime = processQueue[processIndex].arrivalTime;
      continue;
    }
    
    const currentProcess = readyQueue.shift()!;
    const executionTime = Math.min(timeQuantum, currentProcess.remainingTime);
    
    ganttChart.push({
      processId: currentProcess.id,
      start: currentTime,
      end: currentTime + executionTime
    });
    
    currentTime += executionTime;
    currentProcess.remainingTime -= executionTime;
    
    // Add newly arrived processes during execution
    while (processIndex < processQueue.length && processQueue[processIndex].arrivalTime <= currentTime) {
      readyQueue.push(processQueue[processIndex]);
      processIndex++;
    }
    
    // If process not completed, add back to queue
    if (currentProcess.remainingTime > 0) {
      readyQueue.push(currentProcess);
    }
  }
  
  return ganttChart;
}

// Priority Scheduling Algorithm
export function priorityAlgorithm(processes: Process[]): GanttSegment[] {
  const ganttChart: GanttSegment[] = [];
  const remainingProcesses = [...processes];
  let currentTime = 0;
  
  while (remainingProcesses.length > 0) {
    const availableProcesses = remainingProcesses.filter(p => p.arrivalTime <= currentTime);
    
    if (availableProcesses.length === 0) {
      const nextArrival = Math.min(...remainingProcesses.map(p => p.arrivalTime));
      currentTime = nextArrival;
      continue;
    }
    
    // Select highest priority process (lower number = higher priority)
    const highestPriorityProcess = availableProcesses.reduce((highest, current) =>
      current.priority < highest.priority ? current : highest
    );
    
    ganttChart.push({
      processId: highestPriorityProcess.id,
      start: currentTime,
      end: currentTime + highestPriorityProcess.burstTime
    });
    
    currentTime += highestPriorityProcess.burstTime;
    
    const index = remainingProcesses.findIndex(p => p.id === highestPriorityProcess.id);
    remainingProcesses.splice(index, 1);
  }
  
  return ganttChart;
}

// Longest Job First (LJF) Algorithm
export function ljfAlgorithm(processes: Process[]): GanttSegment[] {
  const ganttChart: GanttSegment[] = [];
  const remainingProcesses = [...processes];
  let currentTime = 0;
  
  while (remainingProcesses.length > 0) {
    const availableProcesses = remainingProcesses.filter(p => p.arrivalTime <= currentTime);
    
    if (availableProcesses.length === 0) {
      const nextArrival = Math.min(...remainingProcesses.map(p => p.arrivalTime));
      currentTime = nextArrival;
      continue;
    }
    
    // Select longest job
    const longestJob = availableProcesses.reduce((longest, current) =>
      current.burstTime > longest.burstTime ? current : longest
    );
    
    ganttChart.push({
      processId: longestJob.id,
      start: currentTime,
      end: currentTime + longestJob.burstTime
    });
    
    currentTime += longestJob.burstTime;
    
    const index = remainingProcesses.findIndex(p => p.id === longestJob.id);
    remainingProcesses.splice(index, 1);
  }
  
  return ganttChart;
}

// Highest Response Ratio Next (HRRN) Algorithm
export function hrrnAlgorithm(processes: Process[]): GanttSegment[] {
  const ganttChart: GanttSegment[] = [];
  const remainingProcesses = [...processes];
  let currentTime = 0;
  
  while (remainingProcesses.length > 0) {
    const availableProcesses = remainingProcesses.filter(p => p.arrivalTime <= currentTime);
    
    if (availableProcesses.length === 0) {
      const nextArrival = Math.min(...remainingProcesses.map(p => p.arrivalTime));
      currentTime = nextArrival;
      continue;
    }
    
    // Calculate response ratio for each process
    const processesWithRatio = availableProcesses.map(process => {
      const waitingTime = currentTime - process.arrivalTime;
      const responseRatio = (waitingTime + process.burstTime) / process.burstTime;
      return { ...process, responseRatio };
    });
    
    // Select process with highest response ratio
    const selectedProcess = processesWithRatio.reduce((highest, current) =>
      current.responseRatio > highest.responseRatio ? current : highest
    );
    
    ganttChart.push({
      processId: selectedProcess.id,
      start: currentTime,
      end: currentTime + selectedProcess.burstTime
    });
    
    currentTime += selectedProcess.burstTime;
    
    const index = remainingProcesses.findIndex(p => p.id === selectedProcess.id);
    remainingProcesses.splice(index, 1);
  }
  
  return ganttChart;
}

// Calculate scheduling statistics
export function calculateSchedulingStatistics(
  processes: Process[],
  ganttChart: GanttSegment[]
): SchedulingResult {
  const processDetails = processes.map(process => {
    const segments = ganttChart.filter(segment => segment.processId === process.id);
    const startTime = segments[0]?.start || 0;
    const completionTime = segments[segments.length - 1]?.end || 0;
    const turnaroundTime = completionTime - process.arrivalTime;
    const waitingTime = turnaroundTime - process.burstTime;
    
    return {
      ...process,
      startTime,
      completionTime,
      turnaroundTime,
      waitingTime
    };
  });
  
  const averageWaitingTime = processDetails.reduce((sum, p) => sum + (p.waitingTime || 0), 0) / processes.length;
  const averageTurnaroundTime = processDetails.reduce((sum, p) => sum + (p.turnaroundTime || 0), 0) / processes.length;
  
  const totalTime = Math.max(...ganttChart.map(segment => segment.end));
  const cpuBusyTime = ganttChart.reduce((sum, segment) => sum + (segment.end - segment.start), 0);
  const cpuUtilization = (cpuBusyTime / totalTime) * 100;
  
  return {
    ganttChart,
    averageWaitingTime,
    averageTurnaroundTime,
    cpuUtilization,
    processDetails
  };
}
