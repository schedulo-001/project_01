import { useRef, useState } from 'react';
import { useFrame } from '@react-three/fiber';
import { Text, Box } from '@react-three/drei';
import * as THREE from 'three';

interface MemoryBlockProps {
  address: string;
  size: number;
  isAllocated: boolean;
  processId?: string;
  position: [number, number, number];
  isActive?: boolean;
  onClick?: () => void;
}

export default function MemoryBlock({ 
  address, 
  size, 
  isAllocated, 
  processId, 
  position, 
  isActive = false, 
  onClick 
}: MemoryBlockProps) {
  const meshRef = useRef<THREE.Mesh>(null);
  const [hovered, setHovered] = useState(false);

  // Animation
  useFrame((state) => {
    if (meshRef.current) {
      // Gentle floating for allocated blocks
      if (isAllocated) {
        meshRef.current.position.y = position[1] + Math.sin(state.clock.elapsedTime + position[0]) * 0.05;
      }
      
      // Scale effect when active or hovered
      const targetScale = isActive ? 1.2 : hovered ? 1.1 : 1;
      meshRef.current.scale.lerp(new THREE.Vector3(targetScale, targetScale, targetScale), 0.1);
    }
  });

  // Calculate block height based on size
  const blockHeight = Math.max(0.5, size / 100);
  
  return (
    <group position={position}>
      {/* Memory block */}
      <Box
        ref={meshRef}
        args={[2, blockHeight, 1]}
        onPointerEnter={() => setHovered(true)}
        onPointerLeave={() => setHovered(false)}
        onClick={onClick}
      >
        <meshStandardMaterial
          color={isAllocated ? '#10b981' : '#374151'}
          emissive={isAllocated ? '#059669' : '#1f2937'}
          emissiveIntensity={isActive ? 0.4 : hovered ? 0.2 : 0.1}
          transparent
          opacity={isAllocated ? 0.9 : 0.6}
        />
      </Box>

      {/* Address label */}
      <Text
        position={[0, blockHeight/2 + 0.3, 0.6]}
        fontSize={0.2}
        color="white"
        anchorX="center"
        anchorY="middle"
        font="/fonts/inter.json"
      >
        {address}
      </Text>

      {/* Size label */}
      <Text
        position={[0, 0, 0.6]}
        fontSize={0.25}
        color="white"
        anchorX="center"
        anchorY="middle"
        font="/fonts/inter.json"
      >
        {size}KB
      </Text>

      {/* Process ID (if allocated) */}
      {isAllocated && processId && (
        <Text
          position={[0, -blockHeight/2 - 0.3, 0.6]}
          fontSize={0.2}
          color="#22d3ee"
          anchorX="center"
          anchorY="middle"
          font="/fonts/inter.json"
        >
          {processId}
        </Text>
      )}

      {/* Status indicator */}
      <mesh position={[1.2, 0, 0.6]}>
        <sphereGeometry args={[0.1]} />
        <meshBasicMaterial color={isAllocated ? '#10b981' : '#6b7280'} />
      </mesh>
    </group>
  );
}
