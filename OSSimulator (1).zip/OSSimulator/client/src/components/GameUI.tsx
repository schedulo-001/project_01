import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { 
  Play, 
  Pause, 
  RotateCcw, 
  Settings, 
  BookOpen, 
  Cpu, 
  HardDrive,
  ArrowRight,
  Volume2,
  VolumeX
} from 'lucide-react';
import { useGameState } from '@/lib/stores/useGameState';
import { useScheduling } from '@/lib/stores/useScheduling';
import { useAudio } from '@/lib/stores/useAudio';

export default function GameUI() {
  const { gamePhase, currentTopic, setCurrentTopic, progress } = useGameState();
  const { 
    isRunning, 
    currentAlgorithm, 
    currentStep, 
    totalSteps,
    startSimulation,
    pauseSimulation,
    resetSimulation 
  } = useScheduling();
  const { isMuted, toggleMute } = useAudio();
  
  const [showControls, setShowControls] = useState(true);

  const topics = [
    { id: 'process-states', name: 'Process States', icon: <Settings className="w-4 h-4" /> },
    { id: 'scheduling', name: 'CPU Scheduling', icon: <Cpu className="w-4 h-4" /> },
    { id: 'memory', name: 'Memory Management', icon: <HardDrive className="w-4 h-4" /> },
  ];

  const algorithms = [
    'FCFS', 'SJF', 'SRTF', 'LJF', 'LRTF', 'HRRN', 
    'Round Robin', 'Priority', 'Multilevel Queue', 'Multilevel Feedback Queue'
  ];

  // Auto-hide controls after inactivity
  useEffect(() => {
    const timer = setTimeout(() => {
      if (gamePhase === 'playing') {
        setShowControls(false);
      }
    }, 5000);

    const handleMouseMove = () => {
      setShowControls(true);
      clearTimeout(timer);
    };

    window.addEventListener('mousemove', handleMouseMove);
    return () => {
      clearTimeout(timer);
      window.removeEventListener('mousemove', handleMouseMove);
    };
  }, [gamePhase]);

  if (gamePhase === 'menu') return null;

  return (
    <div className="fixed inset-0 pointer-events-none z-40">
      {/* Top Navigation Bar */}
      <div 
        className={`absolute top-4 left-4 right-4 transition-all duration-300 pointer-events-auto ${
          showControls ? 'opacity-100 translate-y-0' : 'opacity-50 -translate-y-2'
        }`}
      >
        <Card className="bg-black/80 backdrop-blur-md border-gray-700">
          <CardHeader className="pb-2">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-4">
                <CardTitle className="text-white text-lg">OSVerse</CardTitle>
                <div className="flex gap-2">
                  {topics.map((topic) => (
                    <Button
                      key={topic.id}
                      variant={currentTopic === topic.id ? "default" : "outline"}
                      size="sm"
                      onClick={() => setCurrentTopic(topic.id as any)}
                      className="text-xs"
                    >
                      {topic.icon}
                      {topic.name}
                    </Button>
                  ))}
                </div>
              </div>
              
              <div className="flex items-center gap-2">
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={toggleMute}
                  className="text-white hover:bg-gray-700"
                >
                  {isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
                </Button>
                <Badge variant="secondary" className="bg-blue-600 text-white">
                  {gamePhase === 'learning' ? 'Learning Mode' : 'Free Exploration'}
                </Badge>
              </div>
            </div>
          </CardHeader>
          <CardContent className="pt-4">
          </CardContent>
        </Card>
      </div>

      {/* Algorithm Controls (for scheduling topic) */}
      {currentTopic === 'scheduling' && (
        <div className="absolute top-24 left-4 pointer-events-auto">
          <Card className="bg-black/80 backdrop-blur-md border-gray-700 w-80">
            <CardHeader className="pb-2">
              <CardTitle className="text-white text-sm flex items-center gap-2">
                <Cpu className="w-4 h-4" />
                CPU Scheduling Algorithms
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="grid grid-cols-2 gap-2">
                {algorithms.map((algo) => (
                  <Button
                    key={algo}
                    variant={currentAlgorithm === algo ? "default" : "outline"}
                    size="sm"
                    onClick={() => startSimulation(algo)}
                    className="text-xs"
                  >
                    {algo}
                  </Button>
                ))}
              </div>
              
              {currentAlgorithm && (
                <div className="space-y-2">
                  <div className="flex items-center justify-between text-sm text-gray-300">
                    <span>Algorithm: {currentAlgorithm}</span>
                    <span>Step: {currentStep}/{totalSteps}</span>
                  </div>
                  <Progress 
                    value={(currentStep / totalSteps) * 100} 
                    className="h-2"
                  />
                  <div className="flex gap-2">
                    <Button
                      size="sm"
                      onClick={isRunning ? pauseSimulation : () => startSimulation(currentAlgorithm)}
                      className="flex-1"
                    >
                      {isRunning ? <Pause className="w-3 h-3 mr-1" /> : <Play className="w-3 h-3 mr-1" />}
                      {isRunning ? 'Pause' : 'Play'}
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={resetSimulation}
                    >
                      <RotateCcw className="w-3 h-3" />
                    </Button>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      )}

      {/* Progress Indicator */}
      {gamePhase === 'learning' && (
        <div className="absolute bottom-4 left-4 right-4 pointer-events-auto">
          <Card className="bg-black/80 backdrop-blur-md border-gray-700">
            <CardContent className="pt-4">
              <div className="flex items-center justify-between mb-2">
                <span className="text-white text-sm">Learning Progress</span>
                <span className="text-gray-300 text-sm">{progress}%</span>
              </div>
              <Progress value={progress} className="h-2" />
              <div className="flex items-center justify-between mt-2 text-xs text-gray-400">
                <span>Press C for AI Assistant</span>
                <span>Use WASD to move camera</span>
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Instructions Panel */}
      <div className="absolute top-1/2 right-4 transform -translate-y-1/2 pointer-events-auto">
        <Card className="bg-black/80 backdrop-blur-md border-gray-700 w-64">
          <CardHeader className="pb-2">
            <CardTitle className="text-white text-sm flex items-center gap-2">
              <BookOpen className="w-4 h-4" />
              Instructions
            </CardTitle>
          </CardHeader>
          <CardContent className="text-xs text-gray-300 space-y-2">
            <div className="flex items-center gap-2">
              <Badge variant="outline" className="text-xs">WASD</Badge>
              <span>Camera movement</span>
            </div>
            <div className="flex items-center gap-2">
              <Badge variant="outline" className="text-xs">E</Badge>
              <span>Interact with objects</span>
            </div>
            <div className="flex items-center gap-2">
              <Badge variant="outline" className="text-xs">C</Badge>
              <span>Open AI Chatbot</span>
            </div>
            <div className="flex items-center gap-2">
              <Badge variant="outline" className="text-xs">ESC</Badge>
              <span>Return to menu</span>
            </div>
            <div className="flex items-center gap-2">
              <Badge variant="outline" className="text-xs">M</Badge>
              <span>Toggle sound</span>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
