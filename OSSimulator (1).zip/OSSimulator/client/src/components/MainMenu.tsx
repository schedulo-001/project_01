import { useEffect, useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Play, BookOpen, Settings, Info } from 'lucide-react';
import { useGameState } from '@/lib/stores/useGameState';

export default function MainMenu() {
  const { startGame, setGamePhase } = useGameState();
  const [selectedOption, setSelectedOption] = useState(0);

  const menuOptions = [
    {
      title: "Start Learning",
      description: "Begin your journey through Operating System concepts",
      icon: <Play className="w-6 h-6" />,
      action: () => {
        console.log("Starting Learning Mode");
        setGamePhase('concept-selection');
      }
    },
    {
      title: "Free Exploration",
      description: "Explore the 3D environment freely",
      icon: <BookOpen className="w-6 h-6" />,
      action: () => {
        console.log("Starting Free Exploration");
        setGamePhase('playing');
        startGame();
      }
    },
    {
      title: "About",
      description: "Learn about this educational game",
      icon: <Info className="w-6 h-6" />,
      action: () => console.log("About")
    }
  ];

  // Handle keyboard navigation
  useEffect(() => {
    const handleKeyPress = (event: KeyboardEvent) => {
      switch (event.key) {
        case 'ArrowUp':
        case 'w':
        case 'W':
          setSelectedOption((prev) => (prev > 0 ? prev - 1 : menuOptions.length - 1));
          break;
        case 'ArrowDown':
        case 's':
        case 'S':
          setSelectedOption((prev) => (prev < menuOptions.length - 1 ? prev + 1 : 0));
          break;
        case 'Enter':
        case ' ':
          menuOptions[selectedOption]?.action();
          break;
      }
    };

    window.addEventListener('keydown', handleKeyPress);
    return () => window.removeEventListener('keydown', handleKeyPress);
  }, [selectedOption, menuOptions]);

  return (
    <div className="fixed inset-0 z-50 bg-gradient-to-br from-gray-900 via-blue-900 to-purple-900">
      {/* Animated background */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute -top-40 -right-40 w-80 h-80 bg-blue-500 rounded-full mix-blend-multiply filter blur-xl opacity-70 animate-pulse"></div>
        <div className="absolute -bottom-40 -left-40 w-80 h-80 bg-purple-500 rounded-full mix-blend-multiply filter blur-xl opacity-70 animate-pulse delay-1000"></div>
        <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-80 h-80 bg-cyan-500 rounded-full mix-blend-multiply filter blur-xl opacity-70 animate-pulse delay-500"></div>
      </div>

      <div className="relative z-10 flex flex-col items-center justify-center min-h-screen p-8">
        {/* Title */}
        <div className="text-center mb-12">
          <h1 className="text-6xl md:text-8xl font-bold text-white mb-4 tracking-wide">
            OS<span className="text-blue-400">Verse</span>
          </h1>
          <p className="text-xl text-gray-300 max-w-2xl mx-auto leading-relaxed">
            Explore Operating System concepts through immersive 3D visualizations
          </p>
          <div className="mt-6 flex items-center justify-center space-x-4 text-sm text-gray-400">
            <span>Press ↑↓ to navigate</span>
            <span>•</span>
            <span>Enter to select</span>
            <span>•</span>
            <span>C for AI Chatbot</span>
          </div>
        </div>

        {/* Menu Options */}
        <div className="grid gap-6 w-full max-w-4xl">
          {menuOptions.map((option, index) => (
            <Card
              key={index}
              className={`cursor-pointer transition-all duration-300 transform hover:scale-105 ${
                selectedOption === index
                  ? 'bg-gradient-to-r from-blue-600 to-purple-600 border-blue-400 shadow-2xl scale-105'
                  : 'bg-gray-800/50 border-gray-600 hover:bg-gray-700/50'
              }`}
              onClick={option.action}
            >
              <CardHeader className="pb-2">
                <CardTitle className="flex items-center gap-3 text-white text-xl">
                  {option.icon}
                  {option.title}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription className="text-gray-300 text-base">
                  {option.description}
                </CardDescription>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Educational Features Preview */}
        <div className="mt-16 grid grid-cols-1 md:grid-cols-3 gap-6 max-w-4xl">
          <div className="text-center text-white">
            <div className="w-16 h-16 bg-blue-500/20 rounded-full flex items-center justify-center mx-auto mb-4">
              <Settings className="w-8 h-8 text-blue-400" />
            </div>
            <h3 className="font-semibold mb-2">Process Scheduling</h3>
            <p className="text-sm text-gray-400">
              Interactive visualization of FCFS, SJF, Round Robin, and more
            </p>
          </div>
          <div className="text-center text-white">
            <div className="w-16 h-16 bg-purple-500/20 rounded-full flex items-center justify-center mx-auto mb-4">
              <BookOpen className="w-8 h-8 text-purple-400" />
            </div>
            <h3 className="font-semibold mb-2">Memory Management</h3>
            <p className="text-sm text-gray-400">
              3D visualization of memory allocation and paging concepts
            </p>
          </div>
          <div className="text-center text-white">
            <div className="w-16 h-16 bg-cyan-500/20 rounded-full flex items-center justify-center mx-auto mb-4">
              <Info className="w-8 h-8 text-cyan-400" />
            </div>
            <h3 className="font-semibold mb-2">AI Assistant</h3>
            <p className="text-sm text-gray-400">
              Get detailed computer science notes and explanations
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
