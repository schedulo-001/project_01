import { useRef, useState, useMemo } from 'react';
import { useFrame } from '@react-three/fiber';
import { Text, RoundedBox, Cylinder, Sphere } from '@react-three/drei';
import * as THREE from 'three';

interface Process {
  id: number;
  name: string;
  burstTime: number;
  arrivalTime: number;
  priority: number;
  color: string;
  progress: number;
}

export default function CPUSchedulingVisualization() {
  const groupRef = useRef<THREE.Group>(null);
  const cpuCoreRef = useRef<THREE.Mesh>(null);
  const [currentTime, setCurrentTime] = useState(0);
  
  const processes: Process[] = useMemo(() => [
    { id: 1, name: 'P1', burstTime: 8, arrivalTime: 0, priority: 3, color: '#3b82f6', progress: 0 },
    { id: 2, name: 'P2', burstTime: 4, arrivalTime: 1, priority: 1, color: '#10b981', progress: 0 },
    { id: 3, name: 'P3', burstTime: 9, arrivalTime: 2, priority: 4, color: '#f59e0b', progress: 0 },
    { id: 4, name: 'P4', burstTime: 5, arrivalTime: 3, priority: 2, color: '#ef4444', progress: 0 },
    { id: 5, name: 'P5', burstTime: 2, arrivalTime: 4, priority: 5, color: '#8b5cf6', progress: 0 }
  ], []);

  const [readyQueue, setReadyQueue] = useState<Process[]>([]);
  const [runningProcess, setRunningProcess] = useState<Process | null>(null);
  const [completedProcesses, setCompletedProcesses] = useState<Process[]>([]);

  // Simulation logic
  useFrame((state) => {
    const time = state.clock.elapsedTime;
    const simulationTime = Math.floor(time * 2) % 30; // 30 second cycle
    
    if (groupRef.current) {
      groupRef.current.rotation.y = Math.sin(time * 0.05) * 0.05;
    }
    
    // CPU core pulsing animation
    if (cpuCoreRef.current) {
      const scale = 1 + Math.sin(time * 4) * 0.1;
      cpuCoreRef.current.scale.setScalar(scale);
    }
    
    setCurrentTime(simulationTime);
    
    // Simple FCFS simulation logic
    const availableProcesses = processes.filter(p => p.arrivalTime <= simulationTime);
    const notCompleted = availableProcesses.filter(p => p.progress < p.burstTime);
    
    if (notCompleted.length > 0 && !runningProcess) {
      setRunningProcess(notCompleted[0]);
    }
    
    if (runningProcess) {
      const updatedProcess = { ...runningProcess, progress: runningProcess.progress + 0.1 };
      if (updatedProcess.progress >= updatedProcess.burstTime) {
        setCompletedProcesses(prev => [...prev, updatedProcess]);
        setRunningProcess(null);
      } else {
        setRunningProcess(updatedProcess);
      }
    }
    
    setReadyQueue(notCompleted.slice(1));
  });

  return (
    <group ref={groupRef} position={[0, 0, 5]}>
      {/* Title */}
      <Text
        position={[0, 8, 0]}
        fontSize={1.2}
        color="#ffffff"
        anchorX="center"
        anchorY="middle"
      >
        CPU SCHEDULING ALGORITHM
      </Text>
      
      {/* Algorithm Type */}
      <Text
        position={[0, 7, 0]}
        fontSize={0.6}
        color="#22d3ee"
        anchorX="center"
        anchorY="middle"
      >
        First Come First Serve (FCFS)
      </Text>
      
      {/* CPU Core */}
      <group position={[0, 3, 0]}>
        <Cylinder
          ref={cpuCoreRef}
          args={[2, 2, 1.5]}
          rotation={[0, 0, 0]}
          castShadow
          receiveShadow
        >
          <meshStandardMaterial
            color={runningProcess ? runningProcess.color : '#374151'}
            emissive={runningProcess ? runningProcess.color : '#1f2937'}
            emissiveIntensity={0.5}
            roughness={0.3}
            metalness={0.7}
          />
        </Cylinder>
        
        {/* CPU Label */}
        <Text
          position={[0, 0, 0.8]}
          fontSize={0.5}
          color="#ffffff"
          anchorX="center"
          anchorY="middle"
        >
          CPU CORE
        </Text>
        
        {/* Current Process Info */}
        {runningProcess && (
          <>
            <Text
              position={[0, -0.5, 0.8]}
              fontSize={0.4}
              color="#ffffff"
              anchorX="center"
              anchorY="middle"
            >
              {runningProcess.name}
            </Text>
            
            {/* Progress Bar */}
            <RoundedBox
              args={[3, 0.2, 0.1]}
              position={[0, -1.2, 0]}
              radius={0.05}
            >
              <meshStandardMaterial color="#374151" />
            </RoundedBox>
            
            <RoundedBox
              args={[(runningProcess.progress / runningProcess.burstTime) * 3, 0.2, 0.11]}
              position={[-1.5 + ((runningProcess.progress / runningProcess.burstTime) * 3) / 2, -1.2, 0]}
              radius={0.05}
            >
              <meshStandardMaterial 
                color={runningProcess.color}
                emissive={runningProcess.color}
                emissiveIntensity={0.3}
              />
            </RoundedBox>
          </>
        )}
        
        {/* Core activity particles */}
        {runningProcess && (
          <group>
            {Array.from({ length: 12 }, (_, i) => (
              <Sphere
                key={i}
                args={[0.05]}
                position={[
                  Math.cos((i / 12) * Math.PI * 2) * 2.5,
                  Math.sin((i / 12) * Math.PI * 2) * 2.5,
                  Math.sin(Date.now() * 0.003 + i) * 0.3
                ]}
              >
                <meshBasicMaterial
                  color={runningProcess.color}
                  transparent
                  opacity={0.7}
                />
              </Sphere>
            ))}
          </group>
        )}
      </group>
      
      {/* Ready Queue */}
      <group position={[-8, 0, 0]}>
        <Text
          position={[0, 3, 0]}
          fontSize={0.8}
          color="#22d3ee"
          anchorX="center"
          anchorY="middle"
        >
          READY QUEUE
        </Text>
        
        {readyQueue.slice(0, 5).map((process, index) => (
          <group key={process.id} position={[0, 2 - index * 1.2, 0]}>
            <RoundedBox
              args={[2, 0.8, 0.6]}
              radius={0.1}
              castShadow
            >
              <meshStandardMaterial
                color={process.color}
                emissive={process.color}
                emissiveIntensity={0.2}
                roughness={0.4}
                metalness={0.6}
              />
            </RoundedBox>
            
            <Text
              position={[0, 0, 0.4]}
              fontSize={0.3}
              color="#ffffff"
              anchorX="center"
              anchorY="middle"
            >
              {process.name}
            </Text>
            
            <Text
              position={[0, -0.3, 0.4]}
              fontSize={0.2}
              color="#94a3b8"
              anchorX="center"
              anchorY="middle"
            >
              BT: {process.burstTime}
            </Text>
            
            {/* Queue position indicator */}
            <Sphere args={[0.1]} position={[-1.2, 0, 0]}>
              <meshBasicMaterial color="#22d3ee" />
            </Sphere>
          </group>
        ))}
      </group>
      
      {/* Completed Processes */}
      <group position={[8, 0, 0]}>
        <Text
          position={[0, 3, 0]}
          fontSize={0.8}
          color="#10b981"
          anchorX="center"
          anchorY="middle"
        >
          COMPLETED
        </Text>
        
        {completedProcesses.slice(-5).map((process, index) => (
          <group key={`completed-${process.id}`} position={[0, 2 - index * 0.8, 0]}>
            <RoundedBox
              args={[1.5, 0.6, 0.4]}
              radius={0.1}
              castShadow
            >
              <meshStandardMaterial
                color="#10b981"
                emissive="#059669"
                emissiveIntensity={0.3}
                roughness={0.2}
                metalness={0.8}
              />
            </RoundedBox>
            
            <Text
              position={[0, 0, 0.3]}
              fontSize={0.25}
              color="#ffffff"
              anchorX="center"
              anchorY="middle"
            >
              {process.name} ✓
            </Text>
          </group>
        ))}
      </group>
      
      {/* Gantt Chart Timeline */}
      <group position={[0, -3, 0]}>
        <Text
          position={[0, 1, 0]}
          fontSize={0.6}
          color="#ffffff"
          anchorX="center"
          anchorY="middle"
        >
          GANTT CHART TIMELINE
        </Text>
        
        {/* Timeline base */}
        <RoundedBox
          args={[16, 0.3, 0.2]}
          position={[0, 0, 0]}
          radius={0.05}
        >
          <meshStandardMaterial color="#374151" />
        </RoundedBox>
        
        {/* Time markers */}
        {Array.from({ length: 9 }, (_, i) => (
          <group key={i} position={[-8 + i * 2, 0, 0]}>
            <Cylinder args={[0.05, 0.05, 0.5]} position={[0, 0.4, 0]}>
              <meshBasicMaterial color="#22d3ee" />
            </Cylinder>
            <Text
              position={[0, -0.7, 0]}
              fontSize={0.3}
              color="#94a3b8"
              anchorX="center"
              anchorY="middle"
            >
              {i * 5}
            </Text>
          </group>
        ))}
        
        {/* Current time indicator */}
        <Cylinder 
          args={[0.1, 0.1, 1]} 
          position={[-8 + (currentTime / 5) * 2, 0.5, 0]}
        >
          <meshBasicMaterial color="#ef4444" />
        </Cylinder>
      </group>
      
      {/* Performance Metrics */}
      <group position={[0, -6, 0]}>
        <Text
          position={[0, 0, 0]}
          fontSize={0.4}
          color="#22d3ee"
          anchorX="center"
          anchorY="middle"
        >
          Current Time: {currentTime}s | Throughput: {(completedProcesses.length / Math.max(currentTime, 1)).toFixed(2)} proc/s
        </Text>
      </group>
    </group>
  );
}