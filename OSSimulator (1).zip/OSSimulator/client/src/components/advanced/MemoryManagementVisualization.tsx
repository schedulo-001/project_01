import { useRef, useState, useMemo } from 'react';
import { useFrame } from '@react-three/fiber';
import { Text, RoundedBox, Cylinder, Sphere, Line } from '@react-three/drei';
import * as THREE from 'three';

interface MemoryBlock {
  id: number;
  start: number;
  size: number;
  allocated: boolean;
  processId?: string;
  color: string;
  type: 'free' | 'allocated' | 'os';
}

interface Process {
  id: string;
  name: string;
  size: number;
  color: string;
  waitingForAllocation: boolean;
}

export default function MemoryManagementVisualization() {
  const groupRef = useRef<THREE.Group>(null);
  const [currentTime, setCurrentTime] = useState(0);
  
  const memorySize = 1024; // KB
  
  const [memoryBlocks, setMemoryBlocks] = useState<MemoryBlock[]>([
    { id: 0, start: 0, size: 128, allocated: true, processId: 'OS', color: '#1f2937', type: 'os' },
    { id: 1, start: 128, size: 200, allocated: true, processId: 'P1', color: '#3b82f6', type: 'allocated' },
    { id: 2, start: 328, size: 150, allocated: false, color: '#374151', type: 'free' },
    { id: 3, start: 478, size: 180, allocated: true, processId: 'P2', color: '#10b981', type: 'allocated' },
    { id: 4, start: 658, size: 100, allocated: false, color: '#374151', type: 'free' },
    { id: 5, start: 758, size: 120, allocated: true, processId: 'P3', color: '#f59e0b', type: 'allocated' },
    { id: 6, start: 878, size: 146, allocated: false, color: '#374151', type: 'free' }
  ]);
  
  const waitingProcesses: Process[] = useMemo(() => [
    { id: 'P4', name: 'Process 4', size: 80, color: '#ef4444', waitingForAllocation: true },
    { id: 'P5', name: 'Process 5', size: 60, color: '#8b5cf6', waitingForAllocation: true },
    { id: 'P6', name: 'Process 6', size: 90, color: '#06b6d4', waitingForAllocation: true }
  ], []);

  // Animation and simulation
  useFrame((state) => {
    const time = state.clock.elapsedTime;
    setCurrentTime(time);
    
    if (groupRef.current) {
      groupRef.current.rotation.y = Math.sin(time * 0.02) * 0.02;
    }
    
    // Simulate memory allocation/deallocation every 5 seconds
    const cycle = Math.floor(time / 5) % 3;
    if (cycle !== Math.floor((time - 0.016) / 5) % 3) {
      // Trigger memory operation
      simulateMemoryOperation();
    }
  });

  const simulateMemoryOperation = () => {
    // Simple simulation: deallocate and allocate memory
    setMemoryBlocks(prev => {
      const newBlocks = [...prev];
      const randomBlock = newBlocks[Math.floor(Math.random() * newBlocks.length)];
      if (randomBlock.type === 'allocated' && randomBlock.processId !== 'OS') {
        randomBlock.allocated = false;
        randomBlock.processId = undefined;
        randomBlock.color = '#374151';
        randomBlock.type = 'free';
      }
      return newBlocks;
    });
  };

  return (
    <group ref={groupRef} position={[0, 0, -10]}>
      {/* Title */}
      <Text
        position={[0, 8, 0]}
        fontSize={1.2}
        color="#ffffff"
        anchorX="center"
        anchorY="middle"
      >
        MEMORY MANAGEMENT
      </Text>
      
      {/* Memory Management Algorithm */}
      <Text
        position={[0, 7, 0]}
        fontSize={0.6}
        color="#22d3ee"
        anchorX="center"
        anchorY="middle"
      >
        First Fit Algorithm with Dynamic Partitioning
      </Text>
      
      {/* Main Memory Visualization */}
      <group position={[0, 2, 0]}>
        {/* Memory Container Frame */}
        <RoundedBox
          args={[12, 8, 0.2]}
          position={[0, 0, -0.5]}
          radius={0.1}
        >
          <meshStandardMaterial
            color="#1a1a2e"
            transparent
            opacity={0.3}
            wireframe
          />
        </RoundedBox>
        
        {/* Memory Blocks */}
        {memoryBlocks.map((block, index) => {
          const height = (block.size / memorySize) * 7;
          const yPos = 3.5 - (block.start / memorySize) * 7 - height / 2;
          
          return (
            <group key={block.id} position={[0, yPos, 0]}>
              {/* Memory Block */}
              <RoundedBox
                args={[10, height, 0.8]}
                radius={0.05}
                castShadow
                receiveShadow
              >
                <meshStandardMaterial
                  color={block.color}
                  emissive={block.allocated ? block.color : '#000000'}
                  emissiveIntensity={block.allocated ? 0.2 : 0}
                  roughness={0.3}
                  metalness={block.allocated ? 0.7 : 0.1}
                />
              </RoundedBox>
              
              {/* Block Label */}
              <Text
                position={[0, 0, 0.5]}
                fontSize={Math.min(0.4, height * 0.3)}
                color="#ffffff"
                anchorX="center"
                anchorY="middle"
              >
                {block.processId || 'FREE'}
              </Text>
              
              {/* Block Size */}
              <Text
                position={[0, -height * 0.3, 0.5]}
                fontSize={Math.min(0.25, height * 0.2)}
                color="#94a3b8"
                anchorX="center"
                anchorY="middle"
              >
                {block.size} KB
              </Text>
              
              {/* Address Labels */}
              <Text
                position={[-5.5, height / 2, 0]}
                fontSize={0.2}
                color="#22d3ee"
                anchorX="left"
                anchorY="middle"
              >
                {block.start}
              </Text>
              
              <Text
                position={[-5.5, -height / 2, 0]}
                fontSize={0.2}
                color="#22d3ee"
                anchorX="left"
                anchorY="middle"
              >
                {block.start + block.size}
              </Text>
              
              {/* Fragmentation indicators for free blocks */}
              {!block.allocated && (
                <group>
                  {Array.from({ length: Math.floor(height * 2) }, (_, i) => (
                    <Sphere
                      key={i}
                      args={[0.02]}
                      position={[
                        (Math.random() - 0.5) * 9,
                        (Math.random() - 0.5) * height * 0.8,
                        0.5
                      ]}
                    >
                      <meshBasicMaterial
                        color="#ef4444"
                        transparent
                        opacity={0.4}
                      />
                    </Sphere>
                  ))}
                </group>
              )}
            </group>
          );
        })}
        
        {/* Memory Pointer (allocation tracker) */}
        <Line
          points={[new THREE.Vector3(-6, 3.5, 1), new THREE.Vector3(-6, -3.5, 1)]}
          color="#22d3ee"
          lineWidth={2}
        />
        
        <Cylinder args={[0.1, 0.1, 0.3]} position={[-6, 3.8, 1]} rotation={[Math.PI / 2, 0, 0]}>
          <meshBasicMaterial color="#22d3ee" />
        </Cylinder>
      </group>
      
      {/* Waiting Queue */}
      <group position={[-10, 0, 0]}>
        <Text
          position={[0, 4, 0]}
          fontSize={0.8}
          color="#f59e0b"
          anchorX="center"
          anchorY="middle"
        >
          WAITING QUEUE
        </Text>
        
        {waitingProcesses.map((process, index) => (
          <group key={process.id} position={[0, 3 - index * 1.5, 0]}>
            <RoundedBox
              args={[3, 1, 0.6]}
              radius={0.1}
              castShadow
            >
              <meshStandardMaterial
                color={process.color}
                emissive={process.color}
                emissiveIntensity={0.3}
                roughness={0.4}
                metalness={0.6}
              />
            </RoundedBox>
            
            <Text
              position={[0, 0.2, 0.4]}
              fontSize={0.3}
              color="#ffffff"
              anchorX="center"
              anchorY="middle"
            >
              {process.name}
            </Text>
            
            <Text
              position={[0, -0.2, 0.4]}
              fontSize={0.25}
              color="#94a3b8"
              anchorX="center"
              anchorY="middle"
            >
              {process.size} KB
            </Text>
            
            {/* Waiting animation */}
            <Sphere 
              args={[0.05]} 
              position={[1.8 + Math.sin(currentTime * 3 + index) * 0.2, 0, 0.4]}
            >
              <meshBasicMaterial color="#f59e0b" />
            </Sphere>
          </group>
        ))}
      </group>
      
      {/* Memory Statistics */}
      <group position={[10, 0, 0]}>
        <Text
          position={[0, 4, 0]}
          fontSize={0.8}
          color="#10b981"
          anchorX="center"
          anchorY="middle"
        >
          STATISTICS
        </Text>
        
        {/* Total Memory */}
        <group position={[0, 2.5, 0]}>
          <RoundedBox args={[4, 0.6, 0.3]} radius={0.05}>
            <meshStandardMaterial color="#1a1a2e" />
          </RoundedBox>
          <Text
            position={[0, 0, 0.2]}
            fontSize={0.3}
            color="#ffffff"
            anchorX="center"
            anchorY="middle"
          >
            Total: {memorySize} KB
          </Text>
        </group>
        
        {/* Free Memory */}
        <group position={[0, 1.5, 0]}>
          <RoundedBox args={[4, 0.6, 0.3]} radius={0.05}>
            <meshStandardMaterial color="#374151" />
          </RoundedBox>
          <Text
            position={[0, 0, 0.2]}
            fontSize={0.3}
            color="#22d3ee"
            anchorX="center"
            anchorY="middle"
          >
            Free: {memoryBlocks.filter(b => !b.allocated).reduce((sum, b) => sum + b.size, 0)} KB
          </Text>
        </group>
        
        {/* Allocated Memory */}
        <group position={[0, 0.5, 0]}>
          <RoundedBox args={[4, 0.6, 0.3]} radius={0.05}>
            <meshStandardMaterial color="#10b981" />
          </RoundedBox>
          <Text
            position={[0, 0, 0.2]}
            fontSize={0.3}
            color="#ffffff"
            anchorX="center"
            anchorY="middle"
          >
            Used: {memoryBlocks.filter(b => b.allocated).reduce((sum, b) => sum + b.size, 0)} KB
          </Text>
        </group>
        
        {/* Fragmentation */}
        <group position={[0, -0.5, 0]}>
          <RoundedBox args={[4, 0.6, 0.3]} radius={0.05}>
            <meshStandardMaterial color="#ef4444" />
          </RoundedBox>
          <Text
            position={[0, 0, 0.2]}
            fontSize={0.3}
            color="#ffffff"
            anchorX="center"
            anchorY="middle"
          >
            Fragments: {memoryBlocks.filter(b => !b.allocated).length}
          </Text>
        </group>
        
        {/* Memory Utilization Visualization */}
        <group position={[0, -2, 0]}>
          <Text
            position={[0, 0.8, 0]}
            fontSize={0.4}
            color="#22d3ee"
            anchorX="center"
            anchorY="middle"
          >
            UTILIZATION
          </Text>
          
          <Cylinder args={[1.5, 1.5, 0.2]} rotation={[Math.PI / 2, 0, 0]}>
            <meshStandardMaterial color="#1a1a2e" />
          </Cylinder>
          
          {/* Utilization meter */}
          <Cylinder 
            args={[1.3, 1.3, 0.21]} 
            rotation={[Math.PI / 2, 0, 0]}
          >
            <meshStandardMaterial
              color="#10b981"
              emissive="#059669"
              emissiveIntensity={0.3}
              transparent
              opacity={0.8}
            />
          </Cylinder>
          
          <Text
            position={[0, 0, 0.15]}
            fontSize={0.4}
            color="#ffffff"
            anchorX="center"
            anchorY="middle"
          >
            {Math.round((memoryBlocks.filter(b => b.allocated).reduce((sum, b) => sum + b.size, 0) / memorySize) * 100)}%
          </Text>
        </group>
      </group>
      
      {/* Allocation Algorithm Visualization */}
      <group position={[0, -5, 0]}>
        <Text
          position={[0, 1, 0]}
          fontSize={0.6}
          color="#ffffff"
          anchorX="center"
          anchorY="middle"
        >
          ALLOCATION ALGORITHM: FIRST FIT
        </Text>
        
        {/* Algorithm Steps */}
        <Text
          position={[0, 0, 0]}
          fontSize={0.4}
          color="#94a3b8"
          anchorX="center"
          anchorY="middle"
        >
          1. Search from beginning → 2. Find first suitable block → 3. Allocate & Split
        </Text>
        
        {/* Search indicator */}
        <Line
          points={[
            new THREE.Vector3(-8, -0.5, 0),
            new THREE.Vector3(8, -0.5, 0)
          ]}
          color="#22d3ee"
          lineWidth={2}
        />
        
        <Sphere args={[0.1]} position={[-8 + (currentTime * 2) % 16, -0.5, 0]}>
          <meshBasicMaterial color="#22d3ee" />
        </Sphere>
      </group>
      
      {/* Environmental Effects */}
      <pointLight
        position={[0, 10, 5]}
        intensity={2}
        color="#22d3ee"
        distance={20}
        decay={2}
      />
      
      <spotLight
        position={[-10, 8, 5]}
        angle={Math.PI / 6}
        penumbra={0.5}
        intensity={1}
        color="#10b981"
        castShadow
      />
      
      <spotLight
        position={[10, 8, 5]}
        angle={Math.PI / 6}
        penumbra={0.5}
        intensity={1}
        color="#3b82f6"
        castShadow
      />
    </group>
  );
}