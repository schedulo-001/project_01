import { useRef, useState, useMemo } from 'react';
import { useFrame } from '@react-three/fiber';
import { Text, RoundedBox, Sphere, Line, Trail } from '@react-three/drei';
import * as THREE from 'three';

interface ProcessState {
  id: string;
  name: string;
  position: [number, number, number];
  color: string;
  emissiveColor: string;
  active: boolean;
}

export default function ProcessStatesVisualization() {
  const groupRef = useRef<THREE.Group>(null);
  const [activeProcess, setActiveProcess] = useState(0);
  
  const processStates: ProcessState[] = [
    { id: 'new', name: 'NEW', position: [-8, 2, 0], color: '#64748b', emissiveColor: '#475569', active: false },
    { id: 'ready', name: 'READY', position: [-4, 2, 0], color: '#3b82f6', emissiveColor: '#2563eb', active: false },
    { id: 'running', name: 'RUNNING', position: [0, 2, 0], color: '#10b981', emissiveColor: '#059669', active: true },
    { id: 'waiting', name: 'WAITING', position: [4, 2, 0], color: '#f59e0b', emissiveColor: '#d97706', active: false },
    { id: 'terminated', name: 'TERMINATED', position: [8, 2, 0], color: '#ef4444', emissiveColor: '#dc2626', active: false }
  ];

  // Connection paths between states
  const connections = useMemo(() => [
    { from: [-8, 2, 0], to: [-4, 2, 0], color: '#3b82f6' }, // NEW -> READY
    { from: [-4, 2, 0], to: [0, 2, 0], color: '#10b981' },   // READY -> RUNNING
    { from: [0, 2, 0], to: [4, 2, 0], color: '#f59e0b' },    // RUNNING -> WAITING
    { from: [4, 2, 0], to: [-4, 2, 0], color: '#3b82f6' },   // WAITING -> READY
    { from: [0, 2, 0], to: [8, 2, 0], color: '#ef4444' },    // RUNNING -> TERMINATED
    { from: [-4, 2, 0], to: [8, 2, 0], color: '#ef4444' }    // READY -> TERMINATED (preemption)
  ], []);

  // Animate the entire visualization
  useFrame((state) => {
    if (groupRef.current) {
      groupRef.current.rotation.y = Math.sin(state.clock.elapsedTime * 0.1) * 0.1;
      
      // Cycle through active processes
      const newActive = Math.floor(state.clock.elapsedTime * 0.5) % processStates.length;
      setActiveProcess(newActive);
    }
  });

  return (
    <group ref={groupRef} position={[0, 0, -5]}>
      {/* Title */}
      <Text
        position={[0, 6, 0]}
        fontSize={1.2}
        color="#ffffff"
        anchorX="center"
        anchorY="middle"
      >
        PROCESS STATE DIAGRAM
      </Text>
      
      {/* Process State Nodes */}
      {processStates.map((state, index) => (
        <group key={state.id} position={state.position}>
          {/* Main node */}
          <RoundedBox
            args={[2.5, 1.5, 0.8]}
            radius={0.2}
            smoothness={8}
            castShadow
            receiveShadow
          >
            <meshStandardMaterial
              color={index === activeProcess ? '#ffffff' : state.color}
              emissive={state.emissiveColor}
              emissiveIntensity={index === activeProcess ? 0.8 : 0.3}
              roughness={0.2}
              metalness={0.8}
            />
          </RoundedBox>
          
          {/* Glow effect for active state */}
          {index === activeProcess && (
            <Sphere args={[1.8]} position={[0, 0, 0]}>
              <meshBasicMaterial
                color={state.emissiveColor}
                transparent
                opacity={0.2}
              />
            </Sphere>
          )}
          
          {/* State label */}
          <Text
            position={[0, 0, 0.5]}
            fontSize={0.4}
            color={index === activeProcess ? '#000000' : '#ffffff'}
            anchorX="center"
            anchorY="middle"
          >
            {state.name}
          </Text>
          
          {/* Floating particles for active state */}
          {index === activeProcess && (
            <group>
              {Array.from({ length: 8 }, (_, i) => (
                <Sphere
                  key={i}
                  args={[0.05]}
                  position={[
                    Math.cos((i / 8) * Math.PI * 2) * 2,
                    Math.sin((i / 8) * Math.PI * 2) * 2,
                    Math.sin(Date.now() * 0.001 + i) * 0.5
                  ]}
                >
                  <meshBasicMaterial
                    color={state.emissiveColor}
                    transparent
                    opacity={0.8}
                  />
                </Sphere>
              ))}
            </group>
          )}
        </group>
      ))}
      
      {/* Connection Lines with Flow Animation */}
      {connections.map((connection, index) => (
        <group key={index}>
          <Line
            points={[new THREE.Vector3(...connection.from), new THREE.Vector3(...connection.to)]}
            color={connection.color}
            lineWidth={3}
            transparent
            opacity={0.6}
          />
          
          {/* Animated flow particles */}
          <Trail
            width={0.1}
            length={20}
            color={connection.color}
            attenuation={(width) => width}
          >
            <Sphere args={[0.08]}>
              <meshBasicMaterial color={connection.color} />
            </Sphere>
          </Trail>
        </group>
      ))}
      
      {/* Background grid */}
      <mesh position={[0, -1, -2]} rotation={[-Math.PI / 2, 0, 0]}>
        <planeGeometry args={[25, 15]} />
        <meshBasicMaterial
          color="#1a1a2e"
          transparent
          opacity={0.1}
          wireframe
        />
      </mesh>
      
      {/* Atmospheric lighting */}
      <pointLight
        position={[0, 5, 2]}
        intensity={2}
        color="#22d3ee"
        distance={15}
        decay={2}
      />
      
      <spotLight
        position={[0, 8, 5]}
        angle={Math.PI / 4}
        penumbra={0.5}
        intensity={1.5}
        color="#3b82f6"
        castShadow
      />
    </group>
  );
}