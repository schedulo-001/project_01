// Example using Socket.io-client
import { io } from "socket.io-client";
const socket = io("https://your-server-url");

export function sendProcessUpdate(process) {
  socket.emit("process_update", process);
}

export function onProcessUpdate(cb) {
  socket.on("process_update", cb);
}