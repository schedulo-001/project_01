// Expanded scheduling algorithms

export function getFCFSOrder(processes) {
  return processes.slice().sort((a, b) => a.arrival - b.arrival).map(p => p.id);
}
export function getSJFOrder(processes) {
  return processes.slice().sort((a, b) => a.burst - b.burst).map(p => p.id);
}
export function getSRTFOrder(processes) {
  let time = 0, order = [], finished = [];
  let queue = processes.map(p => ({ ...p, remaining: p.burst }));
  while (queue.length) {
    let ready = queue.filter(p => p.arrival <= time && !finished.includes(p.id));
    if (ready.length === 0) { time++; continue; }
    let shortest = ready.reduce((a, b) => (a.remaining < b.remaining ? a : b));
    shortest.remaining--;
    order.push(shortest.id);
    if (shortest.remaining === 0) finished.push(shortest.id);
    time++;
    queue = queue.map(p => p.id === shortest.id ? shortest : p);
  }
  return order;
}
export function getLJFOrder(processes) {
  return processes.slice().sort((a, b) => b.burst - a.burst).map(p => p.id);
}
export function getLRTFOrder(processes) {
  let time = 0, order = [], finished = [];
  let queue = processes.map(p => ({ ...p, remaining: p.burst }));
  while (queue.length) {
    let ready = queue.filter(p => p.arrival <= time && !finished.includes(p.id));
    if (ready.length === 0) { time++; continue; }
    let longest = ready.reduce((a, b) => (a.remaining > b.remaining ? a : b));
    longest.remaining--;
    order.push(longest.id);
    if (longest.remaining === 0) finished.push(longest.id);
    time++;
    queue = queue.map(p => p.id === longest.id ? longest : p);
  }
  return order;
}
export function getHRRNOrder(processes) {
  let time = 0, order = [], finished = [];
  let queue = processes.map(p => ({ ...p, started: false }));
  while (finished.length < processes.length) {
    let ready = queue.filter(p => p.arrival <= time && !finished.includes(p.id));
    if (ready.length === 0) { time++; continue; }
    ready.forEach(p => p.response = (time - p.arrival + p.burst) / p.burst);
    let hrrn = ready.reduce((a, b) => (a.response > b.response ? a : b));
    time += hrrn.burst;
    order.push(hrrn.id);
    finished.push(hrrn.id);
    queue = queue.filter(p => !finished.includes(p.id));
  }
  return order;
}
export function getPriorityOrder(processes) {
  return processes.slice().sort((a, b) => b.priority - a.priority).map(p => p.id);
}
export function getRoundRobinOrder(processes, quantum = 2) {
  let queue = processes.map(p => ({ ...p, remaining: p.burst }));
  let order = [];
  let time = 0;
  while (queue.length) {
    for (let i = 0; i < queue.length; i++) {
      let p = queue[i];
      if (p.remaining > 0) {
        order.push(p.id);
        p.remaining -= quantum;
        time += Math.min(quantum, p.remaining + quantum);
      }
    }
    queue = queue.filter(p => p.remaining > 0);
  }
  return order;
}
export function getMultilevelQueueOrder(processes) {
  // Example: Priority then FCFS
  let high = processes.filter(p => p.priority >= 5);
  let low = processes.filter(p => p.priority < 5);
  return [...getFCFSOrder(high), ...getFCFSOrder(low)];
}
export function getMultilevelFeedbackQueueOrder(processes) {
  // Simple simulation: lower quantum for each level
  let levels = [
    { quantum: 2, queue: [] },
    { quantum: 4, queue: [] }
  ];
  processes.forEach(p => levels[0].queue.push({ ...p, remaining: p.burst }));
  let order = [];
  while (levels[0].queue.length || levels[1].queue.length) {
    for (let l = 0; l < levels.length; l++) {
      let q = levels[l];
      for (let i = 0; i < q.queue.length; i++) {
        let p = q.queue[i];
        let run = Math.min(p.remaining, q.quantum);
        for (let t = 0; t < run; t++) order.push(p.id);
        p.remaining -= run;
        if (p.remaining > 0 && l < levels.length - 1) {
          levels[l + 1].queue.push(p);
        }
      }
      q.queue = q.queue.filter(p => p.remaining > 0);
    }
  }
  return order;
}