import { getFirestore, doc, setDoc, getDoc } from "firebase/firestore";
const db = getFirestore();

export async function saveAchievement(userId, achievement) {
  await setDoc(doc(db, "users", userId), { achievement }, { merge: true });
}