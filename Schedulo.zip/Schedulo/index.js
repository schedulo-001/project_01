import React, { useEffect } from "react";
import { createRoot } from "react-dom/client";
import App from "./App";

// VRButton for WebXR VR support
import { VRButton } from "three/examples/jsm/webxr/VRButton";

const root = createRoot(document.getElementById("root"));
root.render(<App />);

// Attach VRButton to canvas after mount
useEffect(() => {
  const canvas = document.querySelector("canvas");
  if (canvas) document.body.appendChild(VRButton.createButton(canvas));
}, []);