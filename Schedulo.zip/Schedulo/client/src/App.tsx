import { Canvas } from "@react-three/fiber";
import { Suspense, useEffect, useState } from "react";
import { KeyboardControls } from "@react-three/drei";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import "@fontsource/inter";
import "./index.css";

import MainMenu from "./components/MainMenu";
import Game from "./components/Game";
import GameUI from "./components/GameUI";
import Chatbot from "./components/Chatbot";
import ConceptSelector from "./components/ConceptSelector";
import ProcessManagement from "./components/concepts/ProcessManagement";
import { useGameState } from "./lib/stores/useGameState";
import { useAudio } from "./lib/stores/useAudio";

// Define control keys for the game
const controls = [
  { name: "forward", keys: ["KeyW", "ArrowUp"] },
  { name: "backward", keys: ["KeyS", "ArrowDown"] },
  { name: "leftward", keys: ["KeyA", "ArrowLeft"] },
  { name: "rightward", keys: ["KeyD", "ArrowRight"] },
  { name: "interact", keys: ["KeyE"] },
  { name: "jump", keys: ["Space"] },
  { name: "menu", keys: ["Escape"] },
  { name: "chatbot", keys: ["KeyC"] },
];

const queryClient = new QueryClient();

// Main App component
function App() {
  const { gamePhase, currentTopic } = useGameState();
  const { toggleMute } = useAudio();
  const [showCanvas, setShowCanvas] = useState(false);
  const [showChatbot, setShowChatbot] = useState(false);
  
  console.log("Current Game Phase:", gamePhase, "Current Topic:", currentTopic);

  // Initialize audio and show canvas
  useEffect(() => {
    setShowCanvas(true);
    
    // Load audio files
    const backgroundMusic = new Audio("/sounds/background.mp3");
    backgroundMusic.loop = true;
    backgroundMusic.volume = 0.3;
    
    // Auto-play background music (muted by default)
    backgroundMusic.play().catch(() => {
      console.log("Background music autoplay prevented");
    });
  }, []);

  // Handle keyboard shortcuts
  useEffect(() => {
    const handleKeyPress = (event: KeyboardEvent) => {
      if (event.key === "c" || event.key === "C") {
        setShowChatbot(!showChatbot);
      }
      if (event.key === "m" || event.key === "M") {
        toggleMute();
      }
    };

    window.addEventListener("keydown", handleKeyPress);
    return () => window.removeEventListener("keydown", handleKeyPress);
  }, [showChatbot, toggleMute]);

  return (
    <QueryClientProvider client={queryClient}>
      <div style={{ 
        width: '100vw', 
        height: '100vh', 
        position: 'relative', 
        overflow: 'hidden',
        background: 'linear-gradient(135deg, #1a1a2e 0%, #16213e 50%, #0f3460 100%)'
      }}>
        {showCanvas && (
          <KeyboardControls map={controls}>
            {gamePhase === 'menu' && <MainMenu />}
            {gamePhase === 'concept-selection' && <ConceptSelector />}
            {gamePhase === 'learning' && currentTopic === 'process-management' && <ProcessManagement />}
            
            {(gamePhase === 'playing') && (
              <>
                <Canvas
                  shadows
                  camera={{
                    position: [0, 5, 10],
                    fov: 60,
                    near: 0.1,
                    far: 1000
                  }}
                  gl={{
                    antialias: true,
                    powerPreference: "high-performance"
                  }}
                >
                  <color attach="background" args={["#0a0a0a"]} />
                  <Suspense fallback={null}>
                    <Game />
                  </Suspense>
                </Canvas>
                <GameUI />
              </>
            )}
            
            {showChatbot && (
              <Chatbot 
                isOpen={showChatbot} 
                onClose={() => setShowChatbot(false)} 
              />
            )}
          </KeyboardControls>
        )}
        
        {/* Loading screen */}
        {!showCanvas && (
          <div className="flex items-center justify-center w-full h-full">
            <div className="text-center text-white">
              <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-blue-500 mx-auto mb-4"></div>
              <h2 className="text-2xl font-bold">Loading OS Learning Game...</h2>
              <p className="text-gray-300 mt-2">Preparing your 3D educational experience</p>
            </div>
          </div>
        )}
      </div>
    </QueryClientProvider>
  );
}

export default App;
