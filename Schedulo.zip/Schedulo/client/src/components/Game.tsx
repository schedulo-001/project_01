import { useEffect } from 'react';
import { OrbitControls, Text, Environment } from '@react-three/drei';
import { useFrame } from '@react-three/fiber';
import Scene from './3d/Scene';
import GameUI from './GameUI';
import { useGameState } from '@/lib/stores/useGameState';
import { useAudio } from '@/lib/stores/useAudio';

export default function Game() {
  const { gamePhase, currentTopic } = useGameState();
  const { playSuccess } = useAudio();

  // Lighting setup
  const Lights = () => (
    <>
      <ambientLight intensity={0.3} />
      <directionalLight
        position={[10, 10, 5]}
        intensity={1}
        castShadow
        shadow-mapSize-width={2048}
        shadow-mapSize-height={2048}
      />
      <pointLight position={[-10, -10, -10]} intensity={0.5} color="#4f46e5" />
      <spotLight
        position={[0, 20, 0]}
        angle={0.3}
        penumbra={1}
        intensity={0.5}
        castShadow
        color="#06b6d4"
      />
    </>
  );

  // Game loop for updates
  useFrame((state) => {
    // Smooth camera movement based on time
    if (gamePhase === 'learning') {
      const t = state.clock.getElapsedTime();
      state.camera.position.x = Math.sin(t * 0.1) * 2;
    }
  });

  console.log("Game component rendering, gamePhase:", gamePhase);

  return (
    <>
      <Lights />
      
      {/* Environment and atmosphere */}
      <Environment preset="night" />
      

      
      {/* Main 3D Scene */}
      <Scene />
      
      {/* Orbital controls for free exploration */}
      <OrbitControls
        enablePan={gamePhase === 'playing'}
        enableZoom={true}
        enableRotate={true}
        maxDistance={30}
        minDistance={5}
        maxPolarAngle={Math.PI / 2.2}
        target={[0, 0, 0]}
      />
      
      {/* Welcome text */}
      <Text
        position={[0, 8, 0]}
        fontSize={2}
        color="#ffffff"
        anchorX="center"
        anchorY="middle"
      >
        {gamePhase === 'learning' ? 'Learning Mode' : 'Explore OS Concepts'}
      </Text>
    </>
  );
}
