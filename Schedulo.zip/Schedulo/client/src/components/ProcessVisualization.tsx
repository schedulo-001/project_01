import { useState, useEffect } from 'react';
import { Text } from '@react-three/drei';
import ProcessNode from './3d/ProcessNode';
import { ProcessState } from '@/lib/types';
import { useAudio } from '@/lib/stores/useAudio';

const processStates: ProcessState[] = ['new', 'ready', 'running', 'waiting', 'terminated'];

export default function ProcessVisualization() {
  const [processes, setProcesses] = useState([
    {
      id: 'P1',
      name: 'Process 1',
      state: 'new' as ProcessState,
      priority: 1,
      burstTime: 5000,
      arrivalTime: 0,
    },
    {
      id: 'P2',
      name: 'Process 2',
      state: 'ready' as ProcessState,
      priority: 2,
      burstTime: 3000,
      arrivalTime: 1000,
    },
    {
      id: 'P3',
      name: 'Process 3',
      state: 'running' as ProcessState,
      priority: 3,
      burstTime: 8000,
      arrivalTime: 2000,
    },
  ]);

  const [currentDemo, setCurrentDemo] = useState(0);
  const { playSuccess } = useAudio();

  // Demo transitions between process states
  useEffect(() => {
    const interval = setInterval(() => {
      setProcesses(prev => prev.map((process, index) => {
        if (index === currentDemo) {
          const currentStateIndex = processStates.indexOf(process.state);
          const nextStateIndex = (currentStateIndex + 1) % processStates.length;
          playSuccess(); // Play sound on state change
          return { ...process, state: processStates[nextStateIndex] };
        }
        return process;
      }));
      
      setCurrentDemo(prev => (prev + 1) % processes.length);
    }, 3000);

    return () => clearInterval(interval);
  }, [currentDemo, processes.length, playSuccess]);

  return (
    <group position={[-8, 0, 0]}>
      {/* Title */}
      <Text
        position={[0, 6, 0]}
        fontSize={1}
        color="#ffffff"
        anchorX="center"
        anchorY="middle"
        font="/fonts/inter.json"
      >
        Process State Diagram
      </Text>

      {/* Process nodes arranged in a circle */}
      {processes.map((process, index) => {
        const angle = (index / processes.length) * Math.PI * 2;
        const radius = 4;
        const x = Math.cos(angle) * radius;
        const z = Math.sin(angle) * radius;
        
        return (
          <ProcessNode
            key={process.id}
            process={process}
            position={[x, 2, z]}
            isActive={index === currentDemo}
            onClick={() => setCurrentDemo(index)}
          />
        );
      })}

      {/* State transition arrows */}
      <group position={[0, -1, 0]}>
        <Text
          position={[0, 0, 0]}
          fontSize={0.4}
          color="#94a3b8"
          anchorX="center"
          anchorY="middle"
        >
          State Transitions
        </Text>
        
        {/* State legend */}
        {processStates.map((state, index) => (
          <group key={state} position={[index * 2 - 4, -2, 0]}>
            <mesh>
              <boxGeometry args={[0.5, 0.5, 0.5]} />
              <meshStandardMaterial 
                color={
                  state === 'new' ? '#94a3b8' :
                  state === 'ready' ? '#22d3ee' :
                  state === 'running' ? '#10b981' :
                  state === 'waiting' ? '#f59e0b' :
                  '#ef4444'
                }
              />
            </mesh>
            <Text
              position={[0, -1, 0]}
              fontSize={0.3}
              color="white"
              anchorX="center"
              anchorY="middle"
            >
              {state.toUpperCase()}
            </Text>
          </group>
        ))}
      </group>
    </group>
  );
}
