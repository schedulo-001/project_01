import { useRef } from 'react';
import { useFrame } from '@react-three/fiber';
import { Plane, Grid } from '@react-three/drei';
import * as THREE from 'three';

export default function Environment() {
  const groundRef = useRef<THREE.Mesh>(null);

  // Animate ground slightly
  useFrame((state) => {
    if (groundRef.current && groundRef.current.material) {
      const material = groundRef.current.material as THREE.MeshStandardMaterial;
      if (material.color) {
        material.color.setHSL(0.6, 0.1, 0.1 + Math.sin(state.clock.elapsedTime * 0.2) * 0.02);
      }
    }
  });

  return (
    <>
      {/* Ground plane */}
      <Plane 
        ref={groundRef}
        rotation={[-Math.PI / 2, 0, 0]} 
        position={[0, -2, 0]} 
        args={[50, 50]}
        receiveShadow
      >
        <meshStandardMaterial 
          color="#1a1a2e" 
          transparent 
          opacity={0.8}
          roughness={0.8}
          metalness={0.2}
        />
      </Plane>

      {/* Grid overlay */}
      <Grid
        position={[0, -1.9, 0]}
        args={[50, 50]}
        cellSize={2}
        cellThickness={0.5}
        cellColor="#22d3ee"
        sectionSize={10}
        sectionThickness={1}
        sectionColor="#3b82f6"
        fadeDistance={30}
        fadeStrength={1}
        infiniteGrid
      />

      {/* Ambient particles for atmosphere */}
      <group>
        {Array.from({ length: 20 }, (_, i) => (
          <mesh
            key={i}
            position={[
              (Math.random() - 0.5) * 40,
              Math.random() * 15 + 2,
              (Math.random() - 0.5) * 40
            ]}
          >
            <sphereGeometry args={[0.05, 8, 8]} />
            <meshBasicMaterial 
              color="#22d3ee" 
              transparent 
              opacity={0.6}
            />
          </mesh>
        ))}
      </group>

      {/* Fog for depth */}
      <fog attach="fog" args={['#0a0a0a', 5, 50]} />
    </>
  );
}