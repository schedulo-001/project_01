import { useRef, useState } from 'react';
import { useFrame } from '@react-three/fiber';
import { Text, Box, RoundedBox } from '@react-three/drei';
import * as THREE from 'three';

interface Process {
  id: string;
  name: string;
  state: 'new' | 'ready' | 'running' | 'waiting' | 'terminated';
  priority: number;
  burstTime: number;
  arrivalTime: number;
}

interface ProcessNodeProps {
  process: Process;
  position: [number, number, number];
  isActive: boolean;
  onClick?: () => void;
}

export default function ProcessNode({ process, position, isActive, onClick }: ProcessNodeProps) {
  const meshRef = useRef<THREE.Mesh>(null);
  const [hovered, setHovered] = useState(false);

  // Get color based on process state
  const getStateColor = (state: string) => {
    switch (state) {
      case 'new': return '#94a3b8';
      case 'ready': return '#22d3ee';
      case 'running': return '#10b981';
      case 'waiting': return '#f59e0b';
      case 'terminated': return '#ef4444';
      default: return '#6b7280';
    }
  };

  // Animate the node
  useFrame((state) => {
    if (meshRef.current) {
      // Gentle floating animation
      meshRef.current.position.y = position[1] + Math.sin(state.clock.elapsedTime + position[0]) * 0.1;
      
      // Pulse effect when active
      if (isActive) {
        const scale = 1 + Math.sin(state.clock.elapsedTime * 4) * 0.1;
        meshRef.current.scale.set(scale, scale, scale);
      } else {
        meshRef.current.scale.set(1, 1, 1);
      }

      // Glow effect when hovered
      if (hovered) {
        meshRef.current.rotation.y = state.clock.elapsedTime;
      }
    }
  });

  return (
    <group position={position}>
      <RoundedBox
        ref={meshRef}
        args={[2, 1, 0.5]}
        radius={0.1}
        smoothness={4}
        castShadow
        receiveShadow
        onPointerOver={() => setHovered(true)}
        onPointerOut={() => setHovered(false)}
        onClick={onClick}
      >
        <meshStandardMaterial
          color={getStateColor(process.state)}
          emissive={getStateColor(process.state)}
          emissiveIntensity={isActive ? 0.3 : hovered ? 0.2 : 0.1}
          roughness={0.4}
          metalness={0.6}
          transparent
          opacity={0.9}
        />
      </RoundedBox>

      {/* Process ID */}
      <Text
        position={[0, 0, 0.3]}
        fontSize={0.3}
        color="white"
        anchorX="center"
        anchorY="middle"
        font="/fonts/inter.json"
      >
        {process.id}
      </Text>

      {/* Process state */}
      <Text
        position={[0, -0.8, 0]}
        fontSize={0.2}
        color={getStateColor(process.state)}
        anchorX="center"
        anchorY="middle"
      >
        {process.state.toUpperCase()}
      </Text>

      {/* Priority indicator */}
      <Text
        position={[1.2, 0.3, 0]}
        fontSize={0.15}
        color="#94a3b8"
        anchorX="center"
        anchorY="middle"
      >
        P:{process.priority}
      </Text>

      {/* Burst time indicator */}
      <Text
        position={[1.2, -0.1, 0]}
        fontSize={0.15}
        color="#94a3b8"
        anchorX="center"
        anchorY="middle"
      >
        BT:{process.burstTime}
      </Text>

      {/* Connection lines for active processes */}
      {isActive && (
        <line>
          <bufferGeometry>
            <bufferAttribute
              attach="attributes-position"
              count={2}
              array={new Float32Array([0, 0.5, 0, 0, 2, 0])}
              itemSize={3}
            />
          </bufferGeometry>
          <lineBasicMaterial color="#22d3ee" linewidth={2} />
        </line>
      )}
    </group>
  );
}