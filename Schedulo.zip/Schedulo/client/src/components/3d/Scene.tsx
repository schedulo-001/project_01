import { useFrame } from '@react-three/fiber';
import { useRef } from 'react';
import * as THREE from 'three';
import { useGameState } from '@/lib/stores/useGameState';
import ProcessStatesVisualization from '../advanced/ProcessStatesVisualization';
import CPUSchedulingVisualization from '../advanced/CPUSchedulingVisualization';
import MemoryManagementVisualization from '../advanced/MemoryManagementVisualization';
import Environment from './Environment';

export default function Scene() {
  const { currentTopic } = useGameState();
  const sceneRef = useRef<THREE.Group>(null);

  // Animate the scene rotation slightly
  useFrame((state) => {
    if (sceneRef.current) {
      sceneRef.current.rotation.y = Math.sin(state.clock.elapsedTime * 0.1) * 0.05;
    }
  });

  return (
    <group ref={sceneRef}>
      {/* Environment (ground, skybox, etc.) */}
      <Environment />
      
      {/* Advanced OS Concept Visualizations */}
      <ProcessStatesVisualization />
      <CPUSchedulingVisualization />
      <MemoryManagementVisualization />
    </group>
  );
}
