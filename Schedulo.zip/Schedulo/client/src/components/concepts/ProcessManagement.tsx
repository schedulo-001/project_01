import { useState, useRef } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import { OrbitControls, Text, RoundedBox, Sphere, Line } from '@react-three/drei';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { useGameState } from '@/lib/stores/useGameState';
import { ArrowLeft, Play, Pause, RotateCcw } from 'lucide-react';
import * as THREE from 'three';

interface ProcessState {
  id: string;
  name: string;
  position: [number, number, number];
  color: string;
  active: boolean;
}

interface UserProcess {
  pid: number;
  name: string;
  state: string;
  burstTime: number;
  arrivalTime: number;
}

function ProcessVisualization3D({ processes, currentStep }: { processes: UserProcess[], currentStep: number }) {
  const groupRef = useRef<THREE.Group>(null);
  
  const states: ProcessState[] = [
    { id: 'new', name: 'NEW', position: [-6, 0, 0], color: '#64748b', active: false },
    { id: 'ready', name: 'READY', position: [-3, 0, 0], color: '#3b82f6', active: false },
    { id: 'running', name: 'RUNNING', position: [0, 0, 0], color: '#10b981', active: true },
    { id: 'waiting', name: 'WAITING', position: [3, 0, 0], color: '#f59e0b', active: false },
    { id: 'terminated', name: 'TERMINATED', position: [6, 0, 0], color: '#ef4444', active: false }
  ];

  useFrame((state) => {
    if (groupRef.current) {
      groupRef.current.rotation.y = Math.sin(state.clock.elapsedTime * 0.2) * 0.1;
    }
  });

  return (
    <group ref={groupRef}>
      {/* Process States */}
      {states.map((state, index) => (
        <group key={state.id} position={state.position}>
          <RoundedBox
            args={[1.8, 1.2, 0.6]}
            radius={0.1}
            castShadow
            receiveShadow
          >
            <meshStandardMaterial
              color={state.active ? '#ffffff' : state.color}
              emissive={state.color}
              emissiveIntensity={state.active ? 0.6 : 0.2}
              roughness={0.3}
              metalness={0.7}
            />
          </RoundedBox>
          
          <Text
            position={[0, 0, 0.4]}
            fontSize={0.3}
            color={state.active ? '#000000' : '#ffffff'}
            anchorX="center"
            anchorY="middle"
          >
            {state.name}
          </Text>
          
          {/* Show processes in this state */}
          {processes
            .filter(p => p.state.toLowerCase() === state.id)
            .slice(0, 3)
            .map((process, pIndex) => (
              <Sphere
                key={process.pid}
                args={[0.15]}
                position={[0, 0.8 + pIndex * 0.4, 0]}
              >
                <meshStandardMaterial color={state.color} emissive={state.color} emissiveIntensity={0.5} />
              </Sphere>
          ))}
        </group>
      ))}
      
      {/* Arrows showing transitions */}
      <Line
        points={[new THREE.Vector3(-5, 0, 0), new THREE.Vector3(-4, 0, 0)]}
        color="#3b82f6"
        lineWidth={3}
      />
      <Line
        points={[new THREE.Vector3(-2, 0, 0), new THREE.Vector3(-1, 0, 0)]}
        color="#10b981"
        lineWidth={3}
      />
      
      {/* Lighting */}
      <ambientLight intensity={0.4} />
      <directionalLight position={[10, 10, 5]} intensity={1} castShadow />
      <pointLight position={[0, 5, 5]} intensity={0.5} color="#22d3ee" />
    </group>
  );
}

export default function ProcessManagement() {
  const { setGamePhase } = useGameState();
  const [processes, setProcesses] = useState<UserProcess[]>([]);
  const [newProcess, setNewProcess] = useState({ name: '', burstTime: '', arrivalTime: '' });
  const [isSimulating, setIsSimulating] = useState(false);
  const [currentStep, setCurrentStep] = useState(0);
  const [explanation, setExplanation] = useState('');

  const addProcess = () => {
    if (newProcess.name && newProcess.burstTime && newProcess.arrivalTime) {
      const process: UserProcess = {
        pid: processes.length + 1,
        name: newProcess.name,
        state: 'new',
        burstTime: parseInt(newProcess.burstTime),
        arrivalTime: parseInt(newProcess.arrivalTime)
      };
      
      setProcesses([...processes, process]);
      setNewProcess({ name: '', burstTime: '', arrivalTime: '' });
      
      // Generate explanation
      setExplanation(`Process ${process.name} (PID: ${process.pid}) has been created with burst time ${process.burstTime}ms and arrival time ${process.arrivalTime}ms. It starts in the NEW state.`);
    }
  };

  const simulateProcessLifecycle = () => {
    if (processes.length === 0) return;
    
    setIsSimulating(true);
    let step = 0;
    
    const simulate = () => {
      if (step < processes.length * 5) {
        const processIndex = Math.floor(step / 5);
        const stateStep = step % 5;
        const stateNames = ['new', 'ready', 'running', 'waiting', 'terminated'];
        
        setProcesses(prev => prev.map((p, i) => 
          i === processIndex ? { ...p, state: stateNames[stateStep] } : p
        ));
        
        const currentProcess = processes[processIndex];
        const currentState = stateNames[stateStep];
        
        // Update explanation based on current state
        const explanations = {
          'new': `Process ${currentProcess.name} is created and loaded into memory. PCB is allocated.`,
          'ready': `Process ${currentProcess.name} is ready to execute and waiting in the ready queue.`,
          'running': `Process ${currentProcess.name} is currently executing on the CPU.`,
          'waiting': `Process ${currentProcess.name} is waiting for I/O operation or resource to complete.`,
          'terminated': `Process ${currentProcess.name} has completed execution and is being cleaned up.`
        };
        
        setExplanation(explanations[currentState as keyof typeof explanations]);
        setCurrentStep(step);
        
        setTimeout(() => {
          step++;
          if (step < processes.length * 5) {
            simulate();
          } else {
            setIsSimulating(false);
          }
        }, 2000);
      }
    };
    
    simulate();
  };

  const resetSimulation = () => {
    setProcesses(processes.map(p => ({ ...p, state: 'new' })));
    setCurrentStep(0);
    setIsSimulating(false);
    setExplanation('Simulation reset. All processes are back to NEW state.');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900 p-6">
      {/* Header */}
      <div className="flex items-center justify-between mb-8">
        <Button
          variant="outline"
          onClick={() => setGamePhase('concept-selection')}
          className="border-slate-600 text-slate-300 hover:bg-slate-800"
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back to Concepts
        </Button>
        
        <h1 className="text-4xl font-bold text-white">
          Process <span className="text-cyan-400">Management</span>
        </h1>
        
        <div className="w-20"></div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Input Panel */}
        <div className="space-y-6">
          <Card className="bg-slate-800/50 border-slate-700">
            <CardHeader>
              <CardTitle className="text-white">Create New Process</CardTitle>
              <CardDescription className="text-slate-400">
                Enter process details to add to the simulation
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <Input
                placeholder="Process Name (e.g., P1)"
                value={newProcess.name}
                onChange={(e) => setNewProcess(prev => ({ ...prev, name: e.target.value }))}
                className="bg-slate-700 border-slate-600 text-white"
              />
              <Input
                placeholder="Burst Time (ms)"
                type="number"
                value={newProcess.burstTime}
                onChange={(e) => setNewProcess(prev => ({ ...prev, burstTime: e.target.value }))}
                className="bg-slate-700 border-slate-600 text-white"
              />
              <Input
                placeholder="Arrival Time (ms)"
                type="number"
                value={newProcess.arrivalTime}
                onChange={(e) => setNewProcess(prev => ({ ...prev, arrivalTime: e.target.value }))}
                className="bg-slate-700 border-slate-600 text-white"
              />
              <Button onClick={addProcess} className="w-full bg-cyan-600 hover:bg-cyan-700">
                Add Process
              </Button>
            </CardContent>
          </Card>

          {/* Process List */}
          <Card className="bg-slate-800/50 border-slate-700">
            <CardHeader>
              <CardTitle className="text-white">Current Processes</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2 max-h-64 overflow-y-auto">
                {processes.map((process) => (
                  <div key={process.pid} className="flex items-center justify-between p-3 bg-slate-700/50 rounded-lg">
                    <div>
                      <div className="font-medium text-white">{process.name}</div>
                      <div className="text-sm text-slate-400">PID: {process.pid} | BT: {process.burstTime}ms</div>
                    </div>
                    <Badge 
                      variant="outline" 
                      className={`
                        ${process.state === 'new' ? 'border-gray-500 text-gray-400' : ''}
                        ${process.state === 'ready' ? 'border-blue-500 text-blue-400' : ''}
                        ${process.state === 'running' ? 'border-green-500 text-green-400' : ''}
                        ${process.state === 'waiting' ? 'border-yellow-500 text-yellow-400' : ''}
                        ${process.state === 'terminated' ? 'border-red-500 text-red-400' : ''}
                      `}
                    >
                      {process.state.toUpperCase()}
                    </Badge>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Controls */}
          <Card className="bg-slate-800/50 border-slate-700">
            <CardHeader>
              <CardTitle className="text-white">Simulation Controls</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <Button 
                onClick={simulateProcessLifecycle} 
                disabled={isSimulating || processes.length === 0}
                className="w-full bg-green-600 hover:bg-green-700"
              >
                <Play className="w-4 h-4 mr-2" />
                {isSimulating ? 'Simulating...' : 'Start Simulation'}
              </Button>
              
              <Button 
                onClick={resetSimulation}
                disabled={isSimulating}
                className="w-full bg-orange-600 hover:bg-orange-700"
              >
                <RotateCcw className="w-4 h-4 mr-2" />
                Reset Simulation
              </Button>
            </CardContent>
          </Card>
        </div>

        {/* 3D Visualization */}
        <div className="lg:col-span-2">
          <Card className="bg-slate-800/50 border-slate-700 h-96">
            <CardHeader>
              <CardTitle className="text-white">Process State Diagram</CardTitle>
              <CardDescription className="text-slate-400">
                Interactive 3D visualization of process lifecycle
              </CardDescription>
            </CardHeader>
            <CardContent className="h-80">
              <Canvas
                camera={{ position: [0, 3, 8], fov: 60 }}
                className="w-full h-full rounded-lg"
              >
                <color attach="background" args={['#0f172a']} />
                <ProcessVisualization3D processes={processes} currentStep={currentStep} />
                <OrbitControls enablePan={false} />
              </Canvas>
            </CardContent>
          </Card>

          {/* Explanation Panel */}
          <Card className="mt-6 bg-slate-800/50 border-slate-700">
            <CardHeader>
              <CardTitle className="text-white">Real-time Explanation</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="p-4 bg-slate-700/50 rounded-lg">
                <p className="text-slate-300 leading-relaxed">
                  {explanation || 'Add processes and start simulation to see detailed explanations of each state transition.'}
                </p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}