import { useState, useEffect } from 'react';
import { Text, Box } from '@react-three/drei';
import { useScheduling } from '@/lib/stores/useScheduling';
import { useAudio } from '@/lib/stores/useAudio';
import ProcessNode from './3d/ProcessNode';

export default function SchedulingAlgorithms() {
  const { 
    processes, 
    currentAlgorithm, 
    isRunning, 
    currentStep,
    ganttChart 
  } = useScheduling();
  const { playHit } = useAudio();

  // Demo processes for scheduling
  const demoProcesses = [
    { id: 'P1', name: 'Process A', state: 'ready' as const, priority: 3, burstTime: 5, arrivalTime: 0 },
    { id: 'P2', name: 'Process B', state: 'ready' as const, priority: 1, burstTime: 3, arrivalTime: 1 },
    { id: 'P3', name: 'Process C', state: 'ready' as const, priority: 2, burstTime: 8, arrivalTime: 2 },
    { id: 'P4', name: 'Process D', state: 'ready' as const, priority: 4, burstTime: 6, arrivalTime: 3 },
  ];

  // CPU representation
  const CPUCore = ({ isActive, currentProcess }: { isActive: boolean, currentProcess?: string }) => (
    <group position={[0, 4, 0]}>
      <Box args={[3, 1, 1]}>
        <meshStandardMaterial
          color={isActive ? '#10b981' : '#374151'}
          emissive={isActive ? '#059669' : '#1f2937'}
          emissiveIntensity={isActive ? 0.3 : 0.1}
        />
      </Box>
      <Text
        position={[0, 0, 0.6]}
        fontSize={0.4}
        color="white"
        anchorX="center"
        anchorY="middle"
      >
        CPU
      </Text>
      {currentProcess && (
        <Text
          position={[0, -0.8, 0.6]}
          fontSize={0.3}
          color="#22d3ee"
          anchorX="center"
          anchorY="middle"
        >
          Running: {currentProcess}
        </Text>
      )}
    </group>
  );

  // Ready Queue visualization
  const ReadyQueue = ({ processes }: { processes: typeof demoProcesses }) => (
    <group position={[-6, 2, 0]}>
      <Text
        position={[0, 2, 0]}
        fontSize={0.5}
        color="white"
        anchorX="center"
        anchorY="middle"
      >
        Ready Queue
      </Text>
      {processes.map((process, index) => (
        <ProcessNode
          key={process.id}
          process={process}
          position={[0, -index * 1.5, 0]}
          isActive={false}
        />
      ))}
    </group>
  );

  // Gantt Chart visualization
  const GanttChart = ({ chart }: { chart: Array<{processId: string, start: number, end: number}> }) => (
    <group position={[0, -2, 0]}>
      <Text
        position={[0, 2, 0]}
        fontSize={0.5}
        color="white"
        anchorX="center"
        anchorY="middle"
      >
        Gantt Chart
      </Text>
      {chart.map((segment, index) => (
        <group key={index} position={[index * 2 - chart.length, 0, 0]}>
          <Box args={[1.8, 0.8, 0.5]}>
            <meshStandardMaterial
              color="#22d3ee"
              emissive="#0891b2"
              emissiveIntensity={0.2}
            />
          </Box>
          <Text
            position={[0, 0, 0.3]}
            fontSize={0.3}
            color="white"
            anchorX="center"
            anchorY="middle"
          >
            {segment.processId}
          </Text>
          <Text
            position={[0, -1.2, 0]}
            fontSize={0.2}
            color="#94a3b8"
            anchorX="center"
            anchorY="middle"
          >
            {segment.start}-{segment.end}
          </Text>
        </group>
      ))}
    </group>
  );

  return (
    <group position={[8, 0, 0]}>
      {/* Title */}
      <Text
        position={[0, 8, 0]}
        fontSize={1}
        color="#ffffff"
        anchorX="center"
        anchorY="middle"
        font="/fonts/inter.json"
      >
        CPU Scheduling
      </Text>

      {/* Algorithm name */}
      {currentAlgorithm && (
        <Text
          position={[0, 7, 0]}
          fontSize={0.6}
          color="#22d3ee"
          anchorX="center"
          anchorY="middle"
        >
          {currentAlgorithm}
        </Text>
      )}

      {/* CPU Core */}
      <CPUCore 
        isActive={isRunning} 
        currentProcess={ganttChart[currentStep]?.processId}
      />

      {/* Ready Queue */}
      <ReadyQueue processes={demoProcesses.filter(p => p.state === 'ready')} />

      {/* Gantt Chart */}
      {ganttChart.length > 0 && <GanttChart chart={ganttChart.slice(0, currentStep + 1)} />}

      {/* Algorithm explanation */}
      <group position={[6, 2, 0]}>
        <Text
          position={[0, 2, 0]}
          fontSize={0.4}
          color="white"
          anchorX="left"
          anchorY="middle"
        >
          Algorithm Info:
        </Text>
        {currentAlgorithm === 'FCFS' && (
          <Text
            position={[0, 1, 0]}
            fontSize={0.3}
            color="#94a3b8"
            anchorX="left"
            anchorY="middle"
          >
            First Come First Serve{'\n'}
            Non-preemptive{'\n'}
            Simple but can cause{'\n'}
            convoy effect
          </Text>
        )}
        {currentAlgorithm === 'SJF' && (
          <Text
            position={[0, 1, 0]}
            fontSize={0.3}
            color="#94a3b8"
            anchorX="left"
            anchorY="middle"
          >
            Shortest Job First{'\n'}
            Optimal for avg wait time{'\n'}
            Can cause starvation{'\n'}
            for long processes
          </Text>
        )}
        {currentAlgorithm === 'Round Robin' && (
          <Text
            position={[0, 1, 0]}
            fontSize={0.3}
            color="#94a3b8"
            anchorX="left"
            anchorY="middle"
          >
            Round Robin{'\n'}
            Time quantum based{'\n'}
            Fair scheduling{'\n'}
            Good response time
          </Text>
        )}
      </group>
    </group>
  );
}
