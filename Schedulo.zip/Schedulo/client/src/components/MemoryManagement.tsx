import { useState, useEffect } from 'react';
import { Text } from '@react-three/drei';
import MemoryBlock from './3d/MemoryBlock';
import { useAudio } from '@/lib/stores/useAudio';

interface MemoryBlock {
  address: string;
  size: number;
  isAllocated: boolean;
  processId?: string;
}

export default function MemoryManagement() {
  const [memoryBlocks, setMemoryBlocks] = useState<MemoryBlock[]>([
    { address: '0x1000', size: 64, isAllocated: false },
    { address: '0x2000', size: 128, isAllocated: true, processId: 'P1' },
    { address: '0x3000', size: 256, isAllocated: false },
    { address: '0x4000', size: 128, isAllocated: true, processId: 'P2' },
    { address: '0x5000', size: 512, isAllocated: false },
    { address: '0x6000', size: 64, isAllocated: true, processId: 'P3' },
    { address: '0x7000', size: 256, isAllocated: false },
  ]);

  const [currentDemo, setCurrentDemo] = useState(0);
  const [algorithmType, setAlgorithmType] = useState<'first-fit' | 'best-fit' | 'worst-fit'>('first-fit');
  const { playHit } = useAudio();

  // Simulate memory allocation/deallocation
  useEffect(() => {
    const interval = setInterval(() => {
      setMemoryBlocks(prev => {
        const newBlocks = [...prev];
        const blockIndex = currentDemo % newBlocks.length;
        
        // Toggle allocation status
        newBlocks[blockIndex] = {
          ...newBlocks[blockIndex],
          isAllocated: !newBlocks[blockIndex].isAllocated,
          processId: newBlocks[blockIndex].isAllocated ? undefined : `P${blockIndex + 1}`
        };
        
        playHit(); // Play sound on memory change
        return newBlocks;
      });
      
      setCurrentDemo(prev => prev + 1);
    }, 2000);

    return () => clearInterval(interval);
  }, [currentDemo, playHit]);

  // Calculate memory statistics
  const totalMemory = memoryBlocks.reduce((sum, block) => sum + block.size, 0);
  const allocatedMemory = memoryBlocks
    .filter(block => block.isAllocated)
    .reduce((sum, block) => sum + block.size, 0);
  const freeMemory = totalMemory - allocatedMemory;
  const fragmentation = memoryBlocks.filter(block => !block.isAllocated).length;

  return (
    <group position={[0, 0, -8]}>
      {/* Title */}
      <Text
        position={[0, 8, 0]}
        fontSize={1}
        color="#ffffff"
        anchorX="center"
        anchorY="middle"
        font="/fonts/inter.json"
      >
        Memory Management
      </Text>

      {/* Algorithm type */}
      <Text
        position={[0, 7, 0]}
        fontSize={0.6}
        color="#22d3ee"
        anchorX="center"
        anchorY="middle"
      >
        {algorithmType.replace('-', ' ').toUpperCase()} Algorithm
      </Text>

      {/* Memory blocks arranged vertically */}
      {memoryBlocks.map((block, index) => (
        <MemoryBlock
          key={block.address}
          address={block.address}
          size={block.size}
          isAllocated={block.isAllocated}
          processId={block.processId}
          position={[0, 4 - index * 1.2, 0]}
          isActive={index === currentDemo % memoryBlocks.length}
          onClick={() => {
            setMemoryBlocks(prev => {
              const newBlocks = [...prev];
              newBlocks[index] = {
                ...newBlocks[index],
                isAllocated: !newBlocks[index].isAllocated,
                processId: newBlocks[index].isAllocated ? undefined : `P${index + 1}`
              };
              return newBlocks;
            });
          }}
        />
      ))}

      {/* Memory statistics */}
      <group position={[-8, 2, 0]}>
        <Text
          position={[0, 2, 0]}
          fontSize={0.5}
          color="white"
          anchorX="left"
          anchorY="middle"
        >
          Memory Statistics
        </Text>
        
        <Text
          position={[0, 1, 0]}
          fontSize={0.3}
          color="#10b981"
          anchorX="left"
          anchorY="middle"
        >
          Total: {totalMemory}KB
        </Text>
        
        <Text
          position={[0, 0.5, 0]}
          fontSize={0.3}
          color="#22d3ee"
          anchorX="left"
          anchorY="middle"
        >
          Allocated: {allocatedMemory}KB
        </Text>
        
        <Text
          position={[0, 0, 0]}
          fontSize={0.3}
          color="#f59e0b"
          anchorX="left"
          anchorY="middle"
        >
          Free: {freeMemory}KB
        </Text>
        
        <Text
          position={[0, -0.5, 0]}
          fontSize={0.3}
          color="#ef4444"
          anchorX="left"
          anchorY="middle"
        >
          Fragments: {fragmentation}
        </Text>

        <Text
          position={[0, -1.5, 0]}
          fontSize={0.3}
          color="#94a3b8"
          anchorX="left"
          anchorY="middle"
        >
          Utilization: {((allocatedMemory / totalMemory) * 100).toFixed(1)}%
        </Text>
      </group>

      {/* Algorithm explanation */}
      <group position={[8, 2, 0]}>
        <Text
          position={[0, 2, 0]}
          fontSize={0.4}
          color="white"
          anchorX="left"
          anchorY="middle"
        >
          {algorithmType.replace('-', ' ').toUpperCase()}:
        </Text>
        
        {algorithmType === 'first-fit' && (
          <Text
            position={[0, 1, 0]}
            fontSize={0.3}
            color="#94a3b8"
            anchorX="left"
            anchorY="middle"
          >
            Allocates first{'\n'}
            available block{'\n'}
            that fits the{'\n'}
            requested size
          </Text>
        )}
        
        {algorithmType === 'best-fit' && (
          <Text
            position={[0, 1, 0]}
            fontSize={0.3}
            color="#94a3b8"
            anchorX="left"
            anchorY="middle"
          >
            Allocates smallest{'\n'}
            available block{'\n'}
            that fits{'\n'}
            Minimizes waste
          </Text>
        )}
        
        {algorithmType === 'worst-fit' && (
          <Text
            position={[0, 1, 0]}
            fontSize={0.3}
            color="#94a3b8"
            anchorX="left"
            anchorY="middle"
          >
            Allocates largest{'\n'}
            available block{'\n'}
            Leaves bigger{'\n'}
            remaining fragments
          </Text>
        )}

        {/* Algorithm switcher buttons */}
        <group position={[0, -1, 0]}>
          {(['first-fit', 'best-fit', 'worst-fit'] as const).map((algo, index) => (
            <mesh
              key={algo}
              position={[0, -index * 0.8, 0]}
              onClick={() => setAlgorithmType(algo)}
            >
              <boxGeometry args={[3, 0.4, 0.2]} />
              <meshStandardMaterial
                color={algorithmType === algo ? '#22d3ee' : '#374151'}
                emissive={algorithmType === algo ? '#0891b2' : '#1f2937'}
                emissiveIntensity={0.2}
              />
            </mesh>
          ))}
        </group>
      </group>

      {/* Page table visualization */}
      <group position={[0, -6, 0]}>
        <Text
          position={[0, 1, 0]}
          fontSize={0.5}
          color="white"
          anchorX="center"
          anchorY="middle"
        >
          Page Table
        </Text>
        
        {/* Simple page representation */}
        {[0, 1, 2, 3, 4].map(pageNum => (
          <group key={pageNum} position={[pageNum * 2 - 4, 0, 0]}>
            <mesh>
              <boxGeometry args={[1.5, 0.8, 0.3]} />
              <meshStandardMaterial
                color={pageNum % 2 === 0 ? '#10b981' : '#6b7280'}
                emissiveIntensity={0.1}
              />
            </mesh>
            <Text
              position={[0, 0, 0.2]}
              fontSize={0.3}
              color="white"
              anchorX="center"
              anchorY="middle"
            >
              Page {pageNum}
            </Text>
          </group>
        ))}
      </group>
    </group>
  );
}
