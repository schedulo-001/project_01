import { useRef } from 'react';
import { useFrame } from '@react-three/fiber';
import { Text, Box } from '@react-three/drei';
import * as THREE from 'three';

export default function TestVisualization() {
  const boxRef = useRef<THREE.Mesh>(null);

  useFrame((state) => {
    if (boxRef.current) {
      boxRef.current.rotation.x = state.clock.elapsedTime;
      boxRef.current.rotation.y = state.clock.elapsedTime * 0.5;
    }
  });

  return (
    <group>
      {/* Test title */}
      <Text
        position={[0, 5, 0]}
        fontSize={1.5}
        color="#ffffff"
        anchorX="center"
        anchorY="middle"
      >
        Operating System Concepts
      </Text>
      
      {/* Animated test cube */}
      <Box
        ref={boxRef}
        position={[0, 2, 0]}
        args={[2, 2, 2]}
      >
        <meshStandardMaterial 
          color="#22d3ee" 
          emissive="#0891b2" 
          emissiveIntensity={0.3}
        />
      </Box>
      
      {/* Process visualization cubes */}
      <group position={[-6, 0, 0]}>
        <Text
          position={[0, 3, 0]}
          fontSize={0.8}
          color="#ffffff"
          anchorX="center"
          anchorY="middle"
        >
          Process States
        </Text>
        
        {/* New State */}
        <Box position={[0, 1, 0]} args={[1, 1, 1]}>
          <meshStandardMaterial color="#94a3b8" />
        </Box>
        <Text
          position={[0, 0, 0]}
          fontSize={0.3}
          color="#94a3b8"
          anchorX="center"
          anchorY="middle"
        >
          NEW
        </Text>
        
        {/* Ready State */}
        <Box position={[2, 1, 0]} args={[1, 1, 1]}>
          <meshStandardMaterial color="#22d3ee" />
        </Box>
        <Text
          position={[2, 0, 0]}
          fontSize={0.3}
          color="#22d3ee"
          anchorX="center"
          anchorY="middle"
        >
          READY
        </Text>
        
        {/* Running State */}
        <Box position={[4, 1, 0]} args={[1, 1, 1]}>
          <meshStandardMaterial color="#10b981" />
        </Box>
        <Text
          position={[4, 0, 0]}
          fontSize={0.3}
          color="#10b981"
          anchorX="center"
          anchorY="middle"
        >
          RUNNING
        </Text>
        
        {/* Waiting State */}
        <Box position={[2, -1, 0]} args={[1, 1, 1]}>
          <meshStandardMaterial color="#f59e0b" />
        </Box>
        <Text
          position={[2, -2, 0]}
          fontSize={0.3}
          color="#f59e0b"
          anchorX="center"
          anchorY="middle"
        >
          WAITING
        </Text>
        
        {/* Terminated State */}
        <Box position={[0, -1, 0]} args={[1, 1, 1]}>
          <meshStandardMaterial color="#ef4444" />
        </Box>
        <Text
          position={[0, -2, 0]}
          fontSize={0.3}
          color="#ef4444"
          anchorX="center"
          anchorY="middle"
        >
          TERMINATED
        </Text>
      </group>
      
      {/* Scheduling visualization */}
      <group position={[6, 0, 0]}>
        <Text
          position={[0, 3, 0]}
          fontSize={0.8}
          color="#ffffff"
          anchorX="center"
          anchorY="middle"
        >
          CPU Scheduling
        </Text>
        
        {/* CPU Core */}
        <Box position={[0, 1, 0]} args={[3, 0.8, 1]}>
          <meshStandardMaterial color="#10b981" emissive="#059669" emissiveIntensity={0.3} />
        </Box>
        <Text
          position={[0, 1, 0.6]}
          fontSize={0.4}
          color="white"
          anchorX="center"
          anchorY="middle"
        >
          CPU CORE
        </Text>
        
        {/* Ready Queue */}
        {[0, 1, 2].map(i => (
          <Box key={i} position={[-2, -1 - i * 0.8, 0]} args={[1.5, 0.6, 0.8]}>
            <meshStandardMaterial color="#22d3ee" />
          </Box>
        ))}
        <Text
          position={[-2, -3.5, 0]}
          fontSize={0.3}
          color="#22d3ee"
          anchorX="center"
          anchorY="middle"
        >
          READY QUEUE
        </Text>
      </group>
      
      {/* Memory visualization */}
      <group position={[0, 0, 6]}>
        <Text
          position={[0, 3, 0]}
          fontSize={0.8}
          color="#ffffff"
          anchorX="center"
          anchorY="middle"
        >
          Memory Management
        </Text>
        
        {/* Memory blocks */}
        {[0, 1, 2, 3, 4].map(i => (
          <Box 
            key={i} 
            position={[i * 1.2 - 2.4, 0, 0]} 
            args={[1, 2, 0.5]}
          >
            <meshStandardMaterial 
              color={i % 2 === 0 ? "#10b981" : "#374151"} 
              emissive={i % 2 === 0 ? "#059669" : "#1f2937"}
              emissiveIntensity={i % 2 === 0 ? 0.2 : 0.1}
            />
          </Box>
        ))}
        <Text
          position={[0, -2, 0]}
          fontSize={0.3}
          color="#94a3b8"
          anchorX="center"
          anchorY="middle"
        >
          MEMORY BLOCKS
        </Text>
      </group>
    </group>
  );
}