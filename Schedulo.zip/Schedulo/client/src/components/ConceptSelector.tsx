import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { useGameState } from '@/lib/stores/useGameState';
import { 
  Cpu, 
  MemoryStick, 
  Network, 
  HardDrive, 
  Shield, 
  Zap,
  ArrowRight,
  BookOpen
} from 'lucide-react';

interface Concept {
  id: string;
  title: string;
  description: string;
  icon: React.ReactNode;
  color: string;
  difficulty: 'Beginner' | 'Intermediate' | 'Advanced';
  topics: string[];
}

export default function ConceptSelector() {
  const { setCurrentTopic, setGamePhase } = useGameState();
  const [selectedConcept, setSelectedConcept] = useState<string | null>(null);

  const concepts: Concept[] = [
    {
      id: 'process-management',
      title: 'Process Management',
      description: 'Learn about process states, creation, termination, and process control blocks',
      icon: <Cpu className="w-8 h-8" />,
      color: 'from-blue-500 to-cyan-500',
      difficulty: 'Beginner',
      topics: ['Process States', 'Process Creation', 'Process Termination', 'PCB Structure']
    },
    {
      id: 'cpu-scheduling',
      title: 'CPU Scheduling',
      description: 'Master scheduling algorithms like FCFS, SJF, Round Robin, and Priority scheduling',
      icon: <Zap className="w-8 h-8" />,
      color: 'from-green-500 to-emerald-500',
      difficulty: 'Intermediate',
      topics: ['FCFS', 'SJF', 'SRTF', 'Round Robin', 'Priority', 'Multilevel Queue']
    },
    {
      id: 'memory-management',
      title: 'Memory Management',
      description: 'Understand paging, segmentation, virtual memory, and memory allocation strategies',
      icon: <MemoryStick className="w-8 h-8" />,
      color: 'from-purple-500 to-pink-500',
      difficulty: 'Advanced',
      topics: ['Paging', 'Segmentation', 'Virtual Memory', 'Memory Allocation']
    },
    {
      id: 'file-systems',
      title: 'File Systems',
      description: 'Explore file organization, directory structures, and file allocation methods',
      icon: <HardDrive className="w-8 h-8" />,
      color: 'from-orange-500 to-red-500',
      difficulty: 'Intermediate',
      topics: ['File Organization', 'Directory Structure', 'File Allocation', 'File Operations']
    },
    {
      id: 'deadlock-handling',
      title: 'Deadlock Handling',
      description: 'Learn deadlock prevention, avoidance, detection, and recovery strategies',
      icon: <Shield className="w-8 h-8" />,
      color: 'from-red-500 to-pink-500',
      difficulty: 'Advanced',
      topics: ['Deadlock Prevention', 'Deadlock Avoidance', 'Banker\'s Algorithm', 'Recovery']
    },
    {
      id: 'synchronization',
      title: 'Process Synchronization',
      description: 'Master semaphores, monitors, critical sections, and inter-process communication',
      icon: <Network className="w-8 h-8" />,
      color: 'from-teal-500 to-blue-500',
      difficulty: 'Advanced',
      topics: ['Critical Section', 'Semaphores', 'Monitors', 'IPC']
    }
  ];

  const getDifficultyColor = (difficulty: string) => {
    switch(difficulty) {
      case 'Beginner': return 'text-green-400 bg-green-400/10';
      case 'Intermediate': return 'text-yellow-400 bg-yellow-400/10';
      case 'Advanced': return 'text-red-400 bg-red-400/10';
      default: return 'text-gray-400 bg-gray-400/10';
    }
  };

  const handleConceptSelect = (conceptId: string) => {
    setCurrentTopic(conceptId as any);
    setGamePhase('learning');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 p-6">
      {/* Header */}
      <div className="text-center mb-12">
        <h1 className="text-6xl font-bold text-white mb-4 tracking-wider">
          OS <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-purple-400">ACADEMY</span>
        </h1>
        <p className="text-xl text-gray-300 max-w-2xl mx-auto">
          Choose your Operating System concept to explore. Each module offers interactive learning with detailed explanations.
        </p>
        <div className="w-32 h-1 bg-gradient-to-r from-cyan-400 to-purple-400 mx-auto mt-6 rounded-full"></div>
      </div>

      {/* Concept Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 max-w-7xl mx-auto">
        {concepts.map((concept, index) => (
          <Card 
            key={concept.id}
            className={`
              group relative overflow-hidden border-0 bg-slate-800/50 backdrop-blur-sm
              hover:bg-slate-800/80 transition-all duration-500 cursor-pointer
              transform hover:scale-105 hover:rotate-1
              ${selectedConcept === concept.id ? 'ring-2 ring-purple-400' : ''}
            `}
            onClick={() => setSelectedConcept(concept.id)}
            style={{
              animationDelay: `${index * 100}ms`
            }}
          >
            {/* Gradient Background */}
            <div className={`absolute inset-0 bg-gradient-to-br ${concept.color} opacity-10 group-hover:opacity-20 transition-opacity duration-500`}></div>
            
            {/* Content */}
            <CardHeader className="relative">
              <div className="flex items-center justify-between mb-4">
                <div className={`p-3 rounded-lg bg-gradient-to-br ${concept.color} text-white`}>
                  {concept.icon}
                </div>
                <span className={`px-3 py-1 rounded-full text-xs font-medium ${getDifficultyColor(concept.difficulty)}`}>
                  {concept.difficulty}
                </span>
              </div>
              
              <CardTitle className="text-xl font-bold text-white group-hover:text-cyan-300 transition-colors duration-300">
                {concept.title}
              </CardTitle>
              
              <CardDescription className="text-gray-400 text-sm leading-relaxed">
                {concept.description}
              </CardDescription>
            </CardHeader>

            <CardContent className="relative">
              {/* Topics */}
              <div className="mb-6">
                <h4 className="text-sm font-semibold text-cyan-400 mb-3">Topics Covered:</h4>
                <div className="grid grid-cols-2 gap-2">
                  {concept.topics.map((topic, topicIndex) => (
                    <div 
                      key={topicIndex}
                      className="text-xs text-gray-300 bg-slate-700/50 px-2 py-1 rounded-md"
                    >
                      {topic}
                    </div>
                  ))}
                </div>
              </div>

              {/* Action Button */}
              <Button
                onClick={(e) => {
                  e.stopPropagation();
                  handleConceptSelect(concept.id);
                }}
                className={`
                  w-full bg-gradient-to-r ${concept.color} 
                  hover:shadow-lg hover:shadow-purple-500/25
                  transform transition-all duration-300
                  group-hover:scale-105
                `}
              >
                <BookOpen className="w-4 h-4 mr-2" />
                Start Learning
                <ArrowRight className="w-4 h-4 ml-2 group-hover:translate-x-1 transition-transform duration-300" />
              </Button>
            </CardContent>

            {/* Hover Effect */}
            <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none transform -translate-x-full group-hover:translate-x-full" 
                 style={{ transition: 'transform 0.8s ease-in-out, opacity 0.3s ease-in-out' }}></div>
          </Card>
        ))}
      </div>

      {/* Bottom Navigation */}
      <div className="flex justify-center mt-12">
        <Button
          variant="outline"
          className="border-slate-600 text-slate-300 hover:bg-slate-800 hover:text-white"
          onClick={() => setGamePhase('menu')}
        >
          ← Back to Main Menu
        </Button>
      </div>

      {/* Floating Particles Effect */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden">
        {Array.from({ length: 20 }, (_, i) => (
          <div
            key={i}
            className="absolute w-2 h-2 bg-cyan-400/20 rounded-full animate-float"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              animationDelay: `${Math.random() * 5}s`,
              animationDuration: `${5 + Math.random() * 10}s`
            }}
          ></div>
        ))}
      </div>
    </div>
  );
}