import React, { useState, useEffect } from "react";
import { Canvas } from "@react-three/fiber";
import { Suspense } from "react";
import CastleScene from "./components/CastleScene";
import SchedulerControls from "./components/SchedulerControls";
import Gamification from "./components/Gamification";
import AIChatbot from "./components/AIChatbot";
import SoundManager from "./components/SoundManager";
import Multiplayer from "./components/Multiplayer";
import AchievementsCloud from "./components/AchievementsCloud";
import LevelEditor from "./components/LevelEditor";
import AITutor from "./components/AITutor";
import "./App.css";

export default function App() {
  const [selectedAlgorithm, setSelectedAlgorithm] = useState("FCFS");
  const [points, setPoints] = useState(0);
  const [achievements, setAchievements] = useState([]);
  const [userId, setUserId] = useState("demo_user"); // TODO: replace with real auth
  const [level, setLevel] = useState(null);

  useEffect(() => {
    Multiplayer.init(userId, ({ points, achievements }) => {
      setPoints(points);
      setAchievements(achievements);
    });
  }, [userId]);

  useEffect(() => {
    AchievementsCloud.sync(userId, achievements, points);
  }, [achievements, points, userId]);

  return (
    <div style={{ width: "100vw", height: "100vh" }}>
      <SoundManager />
      <Gamification points={points} achievements={achievements} />
      <div style={{ position: "absolute", left: 20, top: 60, zIndex: 10 }}>
        <SchedulerControls
          selected={selectedAlgorithm}
          onChange={setSelectedAlgorithm}
        />
      </div>
      <LevelEditor onSave={setLevel} />
      <Canvas shadows camera={{ position: [0, 8, 14], fov: 50 }} vr>
        <Suspense fallback={null}>
          <CastleScene
            algorithm={selectedAlgorithm}
            setPoints={setPoints}
            setAchievements={setAchievements}
            customLevel={level}
          />
        </Suspense>
      </Canvas>
      <AITutor />
      <AIChatbot className="chatbot" />
    </div>
  );
}