import React, { useRef } from "react";
import { useFrame } from "@react-three/fiber";
import { useTexture } from "@react-three/drei";

const spritePath = "/assets/process_sprite.png";

// Animates a process character (marching toward the throne)
export default function ProcessCharacter({
  process,
  position,
  isLeader,
  onReachThrone,
}) {
  const ref = useRef();
  const texture = useTexture(spritePath);

  // Simple animation: move z toward -4 (throne) and call onReachThrone
  useFrame(() => {
    if (ref.current.position.z > -4) {
      ref.current.position.z -= 0.05 + (isLeader ? 0.04 : 0);
      if (ref.current.position.z <= -4 && onReachThrone) {
        onReachThrone();
      }
    }
  });

  return (
    <mesh ref={ref} position={position} castShadow>
      <boxGeometry args={[1, 1.2, 0.4]} />
      <meshStandardMaterial map={texture} color={isLeader ? "#ffb6b9" : "#8fd3f4"} />
      {/* Floating label */}
      <mesh position={[0, 1, 0]}>
        <textGeometry args={[process.name, { size: 0.3 }]} />
        <meshBasicMaterial color="#222" />
      </mesh>
    </mesh>
  );
}