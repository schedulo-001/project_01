import React from "react";

export default function Gamification({ points, achievements }) {
  return (
    <div className="gamification-bar">
      <span>🏆 Points: <b>{points}</b></span>
      {achievements.length > 0 && (
        <>
          {" | "}
          <span>
            🎖️ Achievements:{" "}
            {achievements.map((a, i) => (
              <span key={i} style={{ marginRight: 6 }}>{a}</span>
            ))}
          </span>
        </>
      )}
    </div>
  );
}