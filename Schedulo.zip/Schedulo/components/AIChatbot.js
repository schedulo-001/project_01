import React, { useState } from "react";

// Demo: Simple AI chatbot UI (stub for integration)
export default function AIChatbot({ className }) {
  const [chat, setChat] = useState([{ user: false, text: "Welcome to the Schedulo AI! Ask me any OS question." }]);
  const [input, setInput] = useState("");

  function sendMessage() {
    if (!input) return;
    setChat([...chat, { user: true, text: input }]);
    // TODO: Integrate with AI backend (e.g., OpenAI or Replicate API)
    setTimeout(() => {
      setChat(chat => [...chat, { user: false, text: "This is a sample answer. (Integrate with OpenAI for real answers!)" }]);
    }, 800);
    setInput("");
  }

  return (
    <div className={className || ""} style={{
      padding: 16, background: "#fff", borderRadius: 22,
      boxShadow: "0 2px 18px #2224", display: "flex", flexDirection: "column"
    }}>
      <div style={{ flex: 1, overflowY: "auto", marginBottom: 10 }}>
        {chat.map((msg, i) => (
          <div key={i} style={{
            textAlign: msg.user ? "right" : "left",
            margin: "8px 0",
            color: msg.user ? "#3b72ff" : "#222"
          }}>
            <span style={{
              background: msg.user ? "#e0e9fa" : "#ffe880",
              borderRadius: 12, padding: "6px 12px",
              display: "inline-block"
            }}>
              {msg.text}
            </span>
          </div>
        ))}
      </div>
      <div style={{ display: "flex", gap: 8 }}>
        <input
          value={input}
          onChange={e => setInput(e.target.value)}
          placeholder="Ask about OS concepts..."
          style={{
            flex: 1, fontSize: "1em", borderRadius: 10, padding: "8px"
          }}
          onKeyDown={e => (e.key === "Enter" ? sendMessage() : null)}
        />
        <button onClick={sendMessage} style={{
          background: "#3b72ff", color: "#fff", border: "none",
          borderRadius: 10, padding: "8px 16px", fontWeight: "bold"
        }}>Send</button>
      </div>
    </div>
  );
}