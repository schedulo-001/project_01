// Achievements cloud sync stub (Firebase ready)
import { getFirestore, doc, setDoc } from "firebase/firestore";
let db = null;
try {
  db = getFirestore(); // requires Firebase setup
} catch (e) {}

const AchievementsCloud = {
  sync: async (userId, achievements, points) => {
    if (!db) return;
    await setDoc(doc(db, "users", userId), { achievements, points }, { merge: true });
  },
};

export default AchievementsCloud;