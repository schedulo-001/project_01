import React from "react";
import { useGLTF, Html } from "@react-three/drei";
import ProcessCharacter from "./ProcessCharacter";
import MemoryTower from "./MemoryTower";
import Particles from "./Particles";
import {
  getFCFSOrder,
  getSJFOrder,
  getSRTFOrder,
  getLJFOrder,
  getLRTFOrder,
  getHRRNOrder,
  getPriorityOrder,
  getRoundRobinOrder,
  getMultilevelQueueOrder,
  getMultilevelFeedbackQueueOrder,
} from "../utils/schedulingAlgorithms";

const castleModelPath = "/assets/castle.glb";
const throneModelPath = "/assets/throne_room.glb";

const sampleProcesses = [
  { id: 1, name: "P1", arrival: 0, burst: 3, priority: 6 },
  { id: 2, name: "P2", arrival: 2, burst: 2, priority: 3 },
  { id: 3, name: "P3", arrival: 4, burst: 1, priority: 8 },
];

export default function CastleScene({
  algorithm,
  setPoints,
  setAchievements,
  customLevel,
}) {
  const { scene: castle } = useGLTF(castleModelPath);
  const { scene: throneRoom } = useGLTF(throneModelPath);

  // Use custom level from LevelEditor if present
  const processes = customLevel
    ? customLevel.filter((obj) => obj.type === "process").map((obj, i) => ({
        ...sampleProcesses[i % sampleProcesses.length],
        position: obj.position,
      }))
    : sampleProcesses;

  // Select algorithm
  let order;
  switch (algorithm) {
    case "FCFS":
      order = getFCFSOrder(processes);
      break;
    case "SJF":
      order = getSJFOrder(processes);
      break;
    case "SRTF":
      order = getSRTFOrder(processes);
      break;
    case "LJF":
      order = getLJFOrder(processes);
      break;
    case "LRTF":
      order = getLRTFOrder(processes);
      break;
    case "HRRN":
      order = getHRRNOrder(processes);
      break;
    case "Priority":
      order = getPriorityOrder(processes);
      break;
    case "Round Robin":
      order = getRoundRobinOrder(processes);
      break;
    case "Multilevel Queue":
      order = getMultilevelQueueOrder(processes);
      break;
    case "Multilevel Feedback Queue":
      order = getMultilevelFeedbackQueueOrder(processes);
      break;
    default:
      order = processes.map((p) => p.id);
  }

  return (
    <group>
      <primitive object={castle} position={[0, 0, 0]} scale={2.7} />
      <primitive object={throneRoom} position={[0, 0, -4]} scale={2.2} />
      <MemoryTower position={[-6, 0, 2]} />
      <MemoryTower position={[6, 0, 2]} />
      <Particles position={[0, 3, -4]} />
      {order.map((processId, idx) => (
        <ProcessCharacter
          key={processId}
          process={processes.find((p) => p.id === processId)}
          position={[-6 + idx * 3, 0.2, 5 - idx * 2]}
          isLeader={idx === 0}
          onReachThrone={() => {
            setPoints((p) => p + 10);
            window.playFX && window.playFX();
          }}
        />
      ))}
      <Html position={[0, 6, 0]}>
        <div style={{ background: "#fff9", borderRadius: 8, padding: 8 }}>
          <b>Welcome to Schedulo!</b> Try switching scheduling algorithms.<br />
          <span style={{ fontSize: "0.9em" }}>
            Processes march to the throne (CPU) in selected order.
          </span>
        </div>
      </Html>
    </group>
  );
}