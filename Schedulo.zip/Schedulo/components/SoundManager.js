import React, { useEffect } from "react";
import useSound from "use-sound";
const music = "/assets/castle_theme.mp3";
const fx = "/assets/process_reach_throne.mp3";

const SoundManager = () => {
  const [playMusic] = useSound(music, { loop: true, volume: 0.5 });
  const [playFX] = useSound(fx, { volume: 1 });

  useEffect(() => {
    playMusic();
  }, [playMusic]);

  // Expose global function for FX
  window.playFX = playFX;

  return null;
};
export default SoundManager;