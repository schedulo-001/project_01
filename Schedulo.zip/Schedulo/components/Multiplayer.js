// Multiplayer Socket.io stub
import { io } from "socket.io-client";
let socket = null;

const Multiplayer = {
  init: (userId, onSync) => {
    socket = io("https://your-multiplayer-server-url"); // <-- replace with real URL
    socket.emit("join", { userId });
    socket.on("sync_state", (data) => {
      if (onSync) onSync(data);
    });
  },
  sendUpdate: (data) => {
    if (!socket) return;
    socket.emit("update_state", data);
  },
};

export default Multiplayer;