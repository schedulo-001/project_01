import React from "react";

const algorithms = [
  "FCFS",
  "SJF",
  "SRTF",
  "LJF",
  "LRTF",
  "HRRN",
  "Priority",
  "Round Robin",
  "Multilevel Queue",
  "Multilevel Feedback Queue",
];

export default function SchedulerControls({ selected, onChange }) {
  return (
    <div style={{
      background: "#fff9",
      padding: "12px",
      borderRadius: "10px",
      boxShadow: "0 2px 8px #2222",
      marginBottom: "10px"
    }}>
      <div style={{ fontWeight: "bold", marginBottom: "8px" }}>
        CPU Scheduling Algorithm
      </div>
      <select
        value={selected}
        onChange={e => onChange(e.target.value)}
        style={{ fontSize: "1em", borderRadius: "6px", padding: "6px", width: "220px" }}
      >
        {algorithms.map(a => (
          <option key={a} value={a}>{a}</option>
        ))}
      </select>
      <div style={{ fontSize: "0.9em", marginTop: "6px" }}>
        Change algorithm to see different process marching orders!
      </div>
    </div>
  );
}