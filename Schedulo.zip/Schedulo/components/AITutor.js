import React, { useState } from "react";

export default function AITutor() {
  const [question, setQuestion] = useState("");
  const [answer, setAnswer] = useState("");
  const [loading, setLoading] = useState(false);

  async function askGPT(q) {
    setLoading(true);
    // Context-aware stub: different canned answers by keyword
    let lower = q.toLowerCase();
    let res = "This is a sample answer. Connect to GPT API for real answers.";
    if (lower.includes("fcfs")) res = "FCFS (First-Come-First-Serve) is a scheduling algorithm where processes are handled in the order they arrive.";
    else if (lower.includes("sjf")) res = "SJF (Shortest Job First) selects the process with the shortest burst time next.";
    else if (lower.includes("memory")) res = "Memory management involves techniques like paging, segmentation, and allocation.";
    else if (lower.includes("multilevel")) res = "Multilevel Queue scheduling divides processes into classes, each with its own scheduling policy.";
    setTimeout(() => {
      setAnswer(res);
      setLoading(false);
    }, 900);
  }

  return (
    <div style={{
      position: "absolute", left: 20, bottom: 20,
      background: "#fff", padding: 14, borderRadius: 12,
      boxShadow: "0 2px 12px #2224", zIndex: 20,
      width: "320px", maxWidth: "98vw"
    }}>
      <b>AI Tutor</b>
      <input
        value={question}
        onChange={e => setQuestion(e.target.value)}
        placeholder="Ask about OS scheduling, memory..."
        style={{ width: "90%", margin: "8px 0", padding: 6, borderRadius: 6 }}
      />
      <button onClick={() => askGPT(question)} disabled={loading} style={{ marginLeft: 6 }}>Ask</button>
      <div style={{ marginTop: 8, minHeight: 30 }}>{loading ? "Thinking..." : answer}</div>
    </div>
  );
}