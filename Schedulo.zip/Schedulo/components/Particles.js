import React from "react";
import { Sparkles } from "@react-three/drei";

export default function Particles({ position }) {
  return (
    <Sparkles
      count={50}
      size={3}
      color="#ffe880"
      position={position || [0, 2, 0]}
      speed={0.5}
      scale={5}
    />
  );
}