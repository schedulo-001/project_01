import React from "react";
import { Html } from "@react-three/drei";

export default function MemoryTower({ position }) {
  return (
    <group position={position}>
      <mesh castShadow receiveShadow>
        <cylinderGeometry args={[0.7, 0.7, 3, 32]} />
        <meshStandardMaterial color="#ffe880" />
      </mesh>
      {/* Label UI */}
      <Html position={[0, 2, 0]}>
        <div style={{ background: "#fff", borderRadius: 6, padding: 4, fontSize: "0.8em", boxShadow: "0 2px 8px #2222" }}>
          Memory Tower
        </div>
      </Html>
    </group>
  );
}