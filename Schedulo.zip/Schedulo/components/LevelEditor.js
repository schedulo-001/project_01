import React, { useState, useEffect, useRef } from "react";
import { Canvas, useFrame } from "@react-three/fiber";
import { Html } from "@react-three/drei";

// Default objects
const defaultLayout = [
  { type: "process", id: 1, position: [-6, 0.2, 5] },
  { type: "memory", id: 2, position: [6, 0, 2] },
  { type: "process", id: 3, position: [0, 0.2, 3] }
];

function loadLevel() {
  try {
    const saved = localStorage.getItem("schedulo_level");
    return saved ? JSON.parse(saved) : defaultLayout;
  } catch {
    return defaultLayout;
  }
}

export default function LevelEditor({ onSave }) {
  const [layout, setLayout] = useState(loadLevel());
  const [draggedId, setDraggedId] = useState(null);

  useEffect(() => {
    const saved = loadLevel();
    setLayout(saved);
  }, []);

  function handleDrag(id, newPos) {
    setLayout(layout =>
      layout.map(obj => obj.id === id ? { ...obj, position: newPos } : obj)
    );
  }

  function saveLevel() {
    if (onSave) onSave(layout);
    localStorage.setItem("schedulo_level", JSON.stringify(layout));
  }

  function resetLevel() {
    setLayout(defaultLayout);
    localStorage.removeItem("schedulo_level");
  }

  return (
    <div className="level-editor"
      style={{ position: "absolute", right: 20, top: 80, zIndex: 15, background: "#fff9", padding: 10, borderRadius: 8, boxShadow: "0 2px 12px #2222" }}>
      <b>Level Editor</b>
      <button onClick={saveLevel} style={{ marginLeft: 8 }}>Save</button>
      <button onClick={resetLevel} style={{ marginLeft: 4 }}>Reset</button>
      <Canvas style={{ height: 240, width: 320 }}>
        {layout.map(obj => (
          <DraggableObject key={obj.id} obj={obj} onDrag={pos => handleDrag(obj.id, pos)} isDragged={draggedId === obj.id} setDraggedId={setDraggedId}/>
        ))}
      </Canvas>
      <Html>
        <div style={{ fontSize: "0.9em", marginTop: 8 }}>Drag objects to design your kingdom.<br />Levels auto-save and load.</div>
      </Html>
    </div>
  );
}

function DraggableObject({ obj, onDrag, isDragged, setDraggedId }) {
  const ref = useRef();
  const dragging = useRef(false);

  useFrame(() => {
    if (dragging.current && ref.current) {
      ref.current.material.color.set("#ffb6b9");
    } else if (ref.current) {
      ref.current.material.color.set(obj.type === "process" ? "#8fd3f4" : "#ffe880");
    }
  });

  // Mouse drag
  function onPointerDown(e) {
    dragging.current = true;
    setDraggedId(obj.id);
    e.stopPropagation();
  }
  function onPointerUp(e) {
    dragging.current = false;
    setDraggedId(null);
    e.stopPropagation();
  }
  function onPointerMove(e) {
    if (dragging.current) {
      const x = (e.unprojectedPoint?.x ?? 0) * 1.5;
      const z = (e.unprojectedPoint?.z ?? 0) * 1.5;
      onDrag([x, obj.position[1], z]);
    }
  }
  // Touch drag
  function onTouchMove(e) {
    dragging.current = true;
    setDraggedId(obj.id);
    const touch = e.touches[0];
    const x = (touch.clientX - 160) / 18;
    const z = (touch.clientY - 120) / 18;
    onDrag([x, obj.position[1], z]);
  }
  function onTouchEnd() {
    dragging.current = false;
    setDraggedId(null);
  }

  return (
    <mesh
      ref={ref}
      position={obj.position}
      onPointerDown={onPointerDown}
      onPointerUp={onPointerUp}
      onPointerMove={onPointerMove}
      onTouchMove={onTouchMove}
      onTouchEnd={onTouchEnd}
      castShadow
    >
      <boxGeometry args={[1, 1, 1]} />
      <meshStandardMaterial color={obj.type === "process" ? "#8fd3f4" : "#ffe880"} />
      <Html>
        <div style={{ fontSize: "0.8em", background: "#fff8", padding: 2, borderRadius: 4 }}>{obj.type} {obj.id}</div>
      </Html>
    </mesh>
  );
}